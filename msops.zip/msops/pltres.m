%
% pltres.m   Plots state of EA populations
%
% E.J.Hughes 11/6/2001
%
%

function pltres(gen,chrom,lb,ub,obj,best,sigma,gind)

nvar=size(chrom,2);

if(nvar==2)  % two genes so plot
  figure(1);
  if(nargin==8)&(nvar==2)
    plot(chrom(:,1),chrom(:,2),'.',best(gen,end-1),best(gen,end),'ro');
  else
    plot(chrom(:,1),chrom(:,2),'.');
  end
  grid;
  xlabel('Gene 1');
  ylabel('Gene 2');
  title(['Chromosome , generation ' num2str(gen)]);
  axis([lb(1) ub(1) lb(2) ub(2)])
else
  figure(1)
  plot(1:nvar,chrom',1:nvar,chrom','.');
  grid;
  xlabel('Loci');
  ylabel('Gene value');
  title(['Chromosome , generation ' num2str(gen)]);
  axis([1 nvar min(lb) max(ub)])
end

sb=size(best,1);

if(size(obj,2)==2) % two objectives so plot
  figure(2)
  plot(obj(:,1),obj(:,2),'o');
  grid;
  xlabel('Objective 1');
  ylabel('Objective 2');
  title(['Objectives , generation ' num2str(gen)]);
else
  figure(2);
  plot(1:sb,best(:,1),1:sb,best(:,2));
  grid;
  xlabel('Generation');
  ylabel('Value');
  title(['Objective - mean and best , generation ' num2str(gen)]);
end

if(nargin==7) % es
 if(nvar==2)  % two genes so plot
   figure(3);
   plot(sigma(:,1),sigma(:,2),'x');
   grid;
   xlabel('\sigma 1');
   ylabel('\sigma 2');
   title(['Mutation sizes , generation ' num2str(gen)]);
 end

 figure(4);
 plot(best(:,end-nvar+1:end))       % plot sigmas of best
 grid;
 xlabel('Generation');
 ylabel('\sigma');
 title(['\sigma values , generation ' num2str(gen)]);

end

if(nargin==8)  %pso
 if(nvar==2)  % two genes so plot
   figure(5);
   plot(sigma(:,1),sigma(:,2),'x');
   grid;
   xlabel('velocity 1');
   ylabel('velocity 2');
   title(['Velocities , generation ' num2str(gen)]);
 end
end

drawnow







