%
% vspace.m  Generates set of reasonably equally spaced vectors.
%
% in 'n' dimensions.
%
% weights = vspace (number of vectors, number of dimensions)
%  
% number of dimensions = N or [angle target_vector]
%                          or [target_start;
%                              target_end]  for fan spread 
%
% E.J.Hughes 29/9/2004

function  wts=vspace(k,n)


ax=180;       % default constriction angle
flaag=0;

if(size(n,2)==1)
 tv = ones(1,n)/sqrt(n);
else
 if(size(n,1)==1) % angle
    ax=n(1);
    tv=n(2:end)/sqrt(sum(n(2:end).^2));
    n=size(n,2)-1;
 else
 % start-stop
    flaag=1;
    A=n(1,:);
	 B=n(2,:);  % start and stop vectors
	 n=size(n,2); 
 end
end
 

if(flaag)
 % fan pattern
 A=A/sqrt(A*A'); % normalised start vector
 B=B/sqrt(B*B'); % normalised stop vector
 
 th=dot(A,B);   % angle between vectors
 th=acos(min(1,th)); % angle in radians
 alpha=linspace(0,th,k); % step angles
 dv=B-A;
 mdv=sqrt(dv*dv'); % magnitude of difference vector
 gamma=acos(min(1,mdv/2)); % top corner angle
 nng=sin(alpha')./sin(alpha'+gamma)/mdv; %normalised distances
 wts=A(ones(k,1),:)+dv(ones(k,1),:).*nng(:,ones(1,n));; % even angle weights
 mag=sqrt(sum((wts.*wts)' )');
 wts=wts./mag(:,ones(1,n));        % normalise
 

else
 
%n=2;          % number of dimensions
%k=30;         % number of vectors
%tv=[1 1];     % target for vectors
%ax=10;        % cone angle for constriction in degrees

ax=cos(ax/180*pi);   % convert to allow quick comparison.

dt=1; % convergence factor
ni=1000;   % max number of iterations
stlev=0.001;   % std level to stop at

wts=[eye(n,n);rand(k-n,n)];  % initial set

mag=sqrt(sum((wts.*wts)' )');
wts=wts./mag(:,ones(1,n));

for it=1:ni

  [a,i]=sort(rand(1,k)); % get scrambled index
  mxang=zeros(1,k);      % record maximum of the cos(angle)
  wtstmp=wts;
  
  for l=1:k
  p=wts(i(l),:);
  ang=wts*p';         % do dot products of all
  q=p*tv';            % dot prod with target
  ang(i(l))=0;        % squash result with itself - 180 degrees
  
  
  [tmp,ind]=max(ang); % get nearest neighbour cos(theta)
  mxang(l)=tmp;
  
  if(0&tmp>0.99999) % if really close, vector too small to push apart
   p=tv+dt*randn(size(p));
  else
   mm=sqrt((wts(ind,:)-p)*(wts(ind,:)-p)');
	if(mm<0.001)
	  mm=0.1;
	else mm=1; end
   p=p-rand*dt*(wts(ind,:)-p)/mm; % move away from closest neighbour
	if(q<ax)
    p=p+rand*dt*(tv-p); % move towards target
	end
  end
  p(p>1)=1;
  p(p<0)=0;              % crop
  mx=sqrt(p*p');
  if(mx==0)
   p=tv+5*dt*randn(size(p));
   mx=sqrt(p*p');
  end 
   p=p/mx;        % normalise
    
  wtstmp(i(l),:)=p;         % update
  
  end
  
  wts=wtstmp;
  
  figure(3001)
  plot(wts(:,1),wts(:,2),'.')
  xlabel('objective 1')
  ylabel('objective 2')
  drawnow
  ss=std(mxang);
  %[mean(mxang) ss]
  %dt=min(4*ss,0.1);
  dt=min(0.1,(acos(min(mxang))-acos(max(mxang)))/acos(mean(mxang))/2000*k);
  if(dt<=stlev) break; end
  end
    
end
  
wts=sortrows(wts);
   
