%
% mso5.m Multiple Single Objective EA
%
% Multi-objective optimisation using multiple single objectives
%
% Uses search vector and angle control.  Weight vector is search direction
%
% Uses elitism on SO vectors
%
% E.J.Hughes 4/6/2003
%

%% parameters common to all EAs

% seed random numbers from system clock
rand('state',sum(100*clock));
randn('state',sum(100*clock));

tv=[];          % default target vector set - cover entire region

% example constrained 2 objective problem
% use default target definition first to do full exploration of space, then uncomment targets
f_obj='objmocons';  % 2 objective function
%tv=[20 0.4234    0.9060]; % 20 degree cone about [0.4234 0.9060]
%tv=[0.36 0.93;0.50 0.87];  % fan with start as [0.36 0.93] and stop as [0.50 0.87]

% highly constrained 2 objective
%f_obj='nobj1';  % objective function, 2 obj, highly constrained
%tv=[0.1339    0.9910; 0.8356    0.5494];  % focus fan of vectors on key region

%example of 3 objectives - solution appears to lie on a line
%f_obj='objmop3';  % 3 objective function
%tv=[ 10  0.2226   0.9749  0]; % 10 degrees about vector [ 0.2226   0.9749   0]
%tv=[1 0 1;0 1 0]; % 2d slice

%example of 4 objectives - solution appears to lie on a line
%f_obj='objmo4';  % 4 objective function
%tv=[ 30 0.9162 0 0.2179 0.3362]; % 30 degrees about vector [0.9162 0 0.2179 0.3362]
%tv=[0.9342    0.1077    0.1981    0.2766; 0.9555         0    0.2664    0.1266]; % 2d slice


p=100;          % population size
maxgen=100;     % maximum number of generations
nwt=50;         % number of target vectors, or [angle target_to_hit]



%% parameters for this technique - Differential evolution

F=0.7;          % reduction factor
C=0.7;          % crossover rate
K=100;          % power to raise cos \theta for VADS
Nn=ceil(p/2);   % neighbours in local niche

fgg=0;             %fgg=1 will start printing out objective surface plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%% Main code

if (Nn>p) Nn=p; end   % trap possible error 

[nobj,ncons,ub,lb]=feval(f_obj);  % get number of objectives and constraints and genes

disp('Generating target vectors')
if(isempty(tv)) tv=nobj; end
wmtx=vspace(nwt,tv);   % create target weight vector set for msops.

figure(3001)
plot(wmtx')
grid
xlabel('objective')
ylabel('magnitude')
title('target vectors')

%% initialise population and variables

if(C<0 | C>1 | F<0 | F>1 )
  disp('Error in C or F')
  F=0.7;
  C=0.5;
end

bnd=[ub;lb];   % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene
nvar=size(bnd,2);           % number of variables
  
pr=C.^(0:nvar-1);           % PDF for exponential crossover

chrom=rand(p,nvar).*(ones(p,1)*rng)+ones(p,1)*bnd(2,:);
                            % initial pop. lb<= x <=ub
gen=0;                      % generation counter
bst=nan*zeros(maxgen,nvar+2*nobj); % stores [mean(obj) min(obj) chrom]

%vector search best
bstwt_obj=inf*ones(1,nwt);
bstwt_o  =zeros(nwt,nobj);
bstwt_ch =zeros(nwt,nvar);  % elitism storage

% min-max best
bstwt_obj_mm=inf*ones(1,nwt);
bstwt_o_mm  =zeros(nwt,nobj);
bstwt_ch_mm =zeros(nwt,nvar);  % elitism storage

ii=ones(p,nwt);            % pseudo ranks for speciation

disp('Initial evaluations ..')

[obj,cons]=feval(f_obj,chrom);     % evaluate initial pop.

%% Main loop

disp('Running ..')

while(gen<maxgen)

  chx=zeros(p,nvar);   % create storage space for new chrom

  % do differential evolution recombination
  % first choose three other chromosomes
  % use local speciation
  for i=1:p

    r=find(ii(i,:)==min(ii(i,:)));  % find best columns
    [fx,iix]=sort(rand(1,length(r))); % generate scrambled list
    r=r(iix(1));                   % scramble order
    [ahh,ihh]=sort(ii(:,r));        % get index of random neighbours
    r=reshape(ihh',1,size(ihh,1)*size(ihh,2)); % reshape to find best
    r=r(1:Nn);                      % index of neighbours 
    r(find(r==i))=[];           % exclude this one
    [fx,iix]=sort(rand(1,length(r))); % generate scrambled list
    r=r(iix);                   % scramble order
    
    chx(i,:)=chrom(i,:);       %copy of chromosome

    %DE/rand/1/exp

    n=floor(rand*nvar);       % place to start crossover
    l=max(find(pr>=rand));    % number to cross
    j=mod(n:(n+l-1),nvar)+1;  % indii of genes to cross
    chx(i,j) = chrom(r(1),j)+F*(chrom(r(2),j)-chrom(r(3),j)); % DE/rand/1/exp
  end
  
  chx=chx+randn(size(chx))*1e-3; % peturb a little
  
  rr=ones(p,1)*bnd(1,:);                 % matrix of upper limits
  chx(chx>rr)=rr(chx>rr);                % crop to upper range
  rr=ones(p,1)*bnd(2,:);                 % matrix of lower limits
  chx(chx<rr)=rr(chx<rr);                % crop to lower range
                                         
                                         
  [objx,consx]=feval(f_obj,chx);         % evaluate objectives  

  objx=[obj;objx];                       % concatenate old obj with new
  consx=[cons;consx];                    % concatenate old constraint with new
  chx=[chrom;chx];                       % concatenate old & new chroms


  %% apply constraints
  tt=max(obj);                           % worse-case for constrained
  objxx=objx;                            % copy objectives
  tt=objx+tt(ones(size(objx,1),1),:).*(2-consx(:,ones(1,nobj))); % softend constraints better           
  objxx(consx<1,:)=tt(consx<1,:);        % mask off constrained solutions
  
  % generate multi-objective ranking
  nrx=zeros(size(objxx,1),nwt);
  nrxwmm=zeros(size(objxx,1),nwt);
  for nx=1:size(objxx,1)
    magn=sqrt(sum(objxx(nx*ones(nwt,1),:)'.^2)); % magnitude of objectives
    csn =sum((objxx(nx*ones(nwt,1),:).*wmtx)')./magn; % cos \theta
    csn(csn>1)=1; % prevent numerical error
    nrx(nx,:)=  magn./(csn.^K+1e-2)+randn(1,nwt)*1e-10; % vector weighted magnitude.
    nrxwmm(nx,:)=max((objxx(nx*ones(nwt,1),:)./(wmtx+1e-30))')+randn(1,nwt)*1e-10; % weighted min-max
  end

  tt=1:nwt;                                     % index vector
  [a,iimm]=sort(nrxwmm);                        % get order of results
  msk=a(1,:)<=bstwt_obj_mm;                     % find if any elite to update
  bstwt_ch_mm(tt(msk),:)=chx(iimm(1,msk),:);    % update elite
  bstwt_o_mm(tt(msk),:) =objx(iimm(1,msk),:);   % update elite
  bstwt_obj_mm(msk)=a(1,msk);                   % update elite obj

  [a,ii]=sort(nrx);                             % get order of results
  msk=a(1,:)<=bstwt_obj;                        % find if any elite to update
  bstwt_ch(tt(msk),:)=chx(ii(1,msk),:);         % update elite
  bstwt_o(tt(msk),:) =objx(ii(1,msk),:);        % update elite
  bstwt_obj(msk)=a(1,msk);                      % update elite obj

  
  tt=(1:size(objx,1))';
  for nx=1:nwt
    ii(ii(:,nx),nx)=tt;                  % give correct rank index
    iimm(iimm(:,nx),nx)=tt;              % give correct rank index
  end
  sv=sort([ii iimm]')';                  % sort to get score vector
  [a,i]=sortrows(sv);                    % get population rank order
  
  obj=objx(i(1:p),:);                    % take best `p' objectives
  chrom=chx(i(1:p),:);                   % take best `p' chromosomes
  cons=consx(i(1:p),:);                  % take best `p' constraints
  ii=ii(i(1:p),:);                       % take best `p' postions
  
  gen=gen+1;                             % increment counter
  bst(gen,:)= [mean(obj) obj(1,:) chrom(1,:)]; % store mean & best

  % plot some graphs
  
    % get pareto set
  mm=find(cons==1);
  r=pareto(obj(mm,:));
  mm=mm(r==1);
  pobj=obj(mm,:);
  pchrom=chrom(mm,:);
  
  figure(1)
  subplot(3,1,2)
  if(length(mm)>1)
   plot(((pchrom-bnd(2*ones(length(mm),1),:))./rng(ones(length(mm),1),:))') % normalised chromosome values
  end
  grid
  xlabel('Genes')
  ylabel('% Magnitude of best')
  subplot(3,1,3)
  if(sum(cons<1))
   plot(((chrom(cons<1,:)-bnd(2*ones(sum(cons<1),1),:))./rng(ones(sum(cons<1),1),:))') % normalised chromosome values
  else plot(0,0)
  end
  grid
  xlabel('Genes')
  ylabel('% Magnitude of constrained')
  subplot(3,1,1)
  plot(((chrom-bnd(2*ones(p,1),:))./rng(ones(p,1),:))') % normalised chromosome values
  grid
  title(['Decision Space, generation ' num2str(gen) ...
	 '  Copyright \copyright 2005 Cranfield University'],'fontsize',8)
  xlabel('Genes')
  ylabel('% Magnitude of all')

  
  figure(2)
  if(nobj==2)
   subplot(1,1,1)
%	  obj(cons==1,1),obj(cons==1,2),'b.', ...
%	  obj(cons<1,1),obj(cons<1,2),'m.', ...
     plot(...
	  bstwt_o_mm(:,1),bstwt_o_mm(:,2),'b*', ...
	  bstwt_o(:,1),bstwt_o(:,2),'ro')
   v=axis;
   dx=sqrt(v(2)^2+v(4)^2);
   hold on
   for nx=1:length(wmtx)
    plot([0;wmtx(nx,1)*dx],[0;wmtx(nx,2)*dx],'r--')
   end
   hold off
   axis(v)
   xlabel('Objective 1','fontsize',8)
   ylabel('Objective 2','fontsize',8)
	grid

	else
	subplot(3,1,2)
	plot(pobj')
	xlabel('Objective')
	ylabel('Best')
	grid
	subplot(3,1,3)
	if(sum(cons<1))
	 plot(obj(cons<1,:)')
	 else plot(0,0)
	end
	xlabel('Objective')
	ylabel('Constrained')
	grid
	subplot(3,1,1)
	plot(obj')
	xlabel('Objective')
	ylabel('All')
	grid
	
   end % end figure 2

   title(['Objective Space, generation ' num2str(gen) ...
	 '  Copyright \copyright 2005 Cranfield University'],'fontsize',8)
   set(gca,'fontsize',8)
   set(2,'PaperUnits','centimeters','PaperPosition',[1 1 12 10]);
   
	if(fgg)
     eval(['print -f1 -djpeg95 figs/img_c_' num2str(fgg) '.jpg']);
     eval(['print -f2 -djpeg95 figs/img_o_' num2str(fgg) '.jpg']);
     fgg=fgg+1;
   end
 
  drawnow
  
end % end of main loop

%figure(10)
%plot(1:size(bst,1),bst(:,1:nvar)) % plot mean and best
%xlabel('generation')

Orange=max(obj)-min(obj)
Olow=min(obj)

%% analyse vectors sums
nrx2=zeros(size(obj,1),nwt);
nrx3=zeros(size(obj,1),nwt);
nrx4=zeros(size(obj,1),nwt);
nrx5=zeros(size(obj,1),nwt);
nrx6=zeros(size(obj,1),nwt);
for nx=1:size(obj,1)
   tt=(obj(nx*ones(nwt,1),:).*wmtx)'; % weighted min-max
   t2=(obj(nx*ones(nwt,1),:).*wmtx)'; % search direction
   t2=sum(t2)./sqrt(sum((wmtx)'.^2))/sqrt(sum(obj(nx,:).^2));
   nrx3(nx,:)=sqrt(sum(tt.^2)); % combination
   nrx4(nx,:)=sum(abs(ones(nwt,1)*obj(nx,:))'); % combination
   nrx5(nx,:)=acos(t2)*180/pi;  % error angle
   nrx6(nx,:)=sum(abs(ones(nwt,1)*((obj(nx,:)-Olow)./Orange))'); % combination
end

[a,i]=min(nrx5);    % find closest to each
b=diag(nrx3(i,:))';
c=diag(nrx4(i,:))';
cx=diag(nrx6(i,:))';
d=diag(nrx5(i,:))';

w1=zeros(nwt,nwt);
for nx=1:nwt
   t2=(wmtx(nx*ones(nwt,1),:).*wmtx)'; % search direction
   t2=sum(t2)./sqrt(sum((wmtx)'.^2))/sqrt(sum(wmtx(nx,:).^2));
   t2(t2>1)=1;
   w1(nx,:)=acos(t2)*180/pi;  % error angle
end

[a,i]=sort(w1);
e=diag(w1(i(2,:),:))';


figure(1000)
%bar(a./c*100) 
bar(d) 
xlabel('weight set')
%ylabel('% error indication')
ylabel('angular error indication (degrees)')
title('Best solution wrt weights - convergence indication and objective set limits')
grid
%axis([0.5 nwt+0.5 0 100*max(a./c)])
axis([0.5 nwt+0.5 0 max(d)])

%[ax,i]=sortrows(wmtx,2);
%bar(d(i))

figure(1001)
bar(c) 
xlabel('weight set')
ylabel('Objective Sum')
title('Best solution wrt weights - weight set profile')
grid
axis([0.5 nwt+0.5 0 max(c)])


%figure(1002)
%ll=1;  % error limit, typical after good convergence
%i=find(d<ll);  % get good ones
%ix=find(d>=ll);  % get bad ones
%plot(wmtx(i,1),wmtx(i,2),'ro',wmtx(ix,1),wmtx(ix,2),'b.')
%grid


% min-max spread
f=bstwt_o_mm.*wmtx;
f=sum(f')./sqrt(sum(wmtx'.^2))./sqrt(sum(bstwt_o_mm'.^2));
f(f>1)=1;
f=acos(f)*180/pi;

%vads spread
g=bstwt_o.*wmtx;
g=sum(g')./sqrt(sum(wmtx'.^2))./sqrt(sum(bstwt_o'.^2));
g(g>1)=1;
g=acos(g)*180/pi;
ll=g<20;   % mask of 2 degree limit

hh=bstwt_o_mm(ll,:);
hh=hh./(sqrt(sum(hh'.^2))'*ones(1,nobj));
max(hh)
min(hh)

figure(1005)
bar(f)
xlabel('Weight vector index')
ylabel('Min-Max angular error')
title('Min-Max Angular error - Pareto front convergence')
grid
axis([0.5 nwt+0.5 0 max(f)])
figure(1006)
bar(g)
xlabel('Weight vector index')
ylabel('VADS angular error')
title('VADS Angular error - Objective front convergence')
grid
axis([0.5 nwt+0.5 0 max(g)])

figure(1007)
bar(f-g)
xlabel('Weight vector index')
ylabel('WMM-VADS angular error')
title('Angular error Difference - large +ive for Discontinuities in Pareto set')
grid
axis([0.5 nwt+0.5 min(f-g) max(f-g)])

%%normalise:
%noo=(obj-ones(p,1)*Olow)./(ones(p,1)*Orange);
%c=sum(noo');

%figure(1008)
%bar(c) 
%xlabel('weight set')
%ylabel('Normalised Objective Sum')
%title('Best solution wrt weights')
%grid
%axis([0.5 nwt+0.5 0 max(c)])


%figure(1009)
%x=[obj(:,1)';obj(:,1)';NaN*ones(1,p)];
%y=[obj(:,2)';obj(:,2)';NaN*ones(1,p)];
%z=[obj(:,3)';zeros(1,p);NaN*ones(1,p)];

%k=sortrows(obj);

%plot3( obj(:,1),obj(:,2),obj(:,3),'r.')
%hold on
%plot3(reshape(x,3*p,1),reshape(y,3*p,1),reshape(z,3*p,1),'b-', ...
%     k(:,1),k(:,2),zeros(p,1),'b-')
%hold off
%grid
%xlabel('Objective 1')
%ylabel('Objective 2')
%zlabel('Objective 3')

% obj has all objectives
% chrom has chromosomes
% cons has constraint
% pobj has pareto objectives
% pchrom has pareto chromosomes
% wmtx has target vectors.
