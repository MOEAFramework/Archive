% objmocons.m  Objective function 
% 
% constraint =1 is ok, 0 does not work.
%
% E.J.Hughes 30/11/00


function [obj,c,ub,lb]=objmocons(Chrom,flaag)

nobj=2;                           % 2 objectives
ncons=1;                          % 1 constraint 

ub=[1 1];  % upper bound on genes (2 gene problem)
lb=[0 0];  % lower bound on genes

if nargin==0
  obj=nobj;
  c=ncons;
  return;
end


[popsize,nvar]=size(Chrom);


% Loop for all chromosomes 

obj=zeros(popsize,nobj);
c  = ones(popsize,1);      % all unconstrained to start

for hjj=1:popsize

  chrom=Chrom(hjj,:) * pi;  % 0-1 now 0 to pi

  x=chrom(1);
  y=chrom(2);
  
  %% Calculate objectives

  o1=x/pi;
  o2=y/pi;

  obj(hjj,:)=[o1 o2];
  
  c1 = 0>= -(x^2) - (y^2) +1 + 0.1 * cos(16 * atan2(y,x));
  c2 = 0.5>= (x-0.5)^2 + (y-0.5)^2;
  
  c(hjj,:)  = sqrt(c1*c2);   % geometric mean of constraints
  
end





