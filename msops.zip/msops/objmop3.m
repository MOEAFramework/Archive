% mop3.m  Objective function 
% 
% Viennet(3) 3 objective function
%
% E.J.Hughes 3/6/2003


function [obj,c,ub,lb]=objmop3(Chrom,flaag)

nobj=3;                           % 3 objectives
ncons=1;                          % 1 constraint 

ub=[6 6];  % upper bound on genes
lb=[0 0];  % lower bound on genes

if nargin==0
  obj=nobj;
  c=ncons;
  return;
end


[popsize,nvar]=size(Chrom);


% Loop for all chromosomes 

obj=zeros(popsize,nobj);
c  =ones(popsize,1);      % all unconstrained to start

for hjj=1:popsize

  chrom=Chrom(hjj,:); 

  x=chrom(1)-3;
  y=chrom(2)-3;  % now [-3,3]
  
  %% Calculate objectives

  o1=0.5*(x^2+y^2)+sin(x^2+y^2);
  o2=(3*x-2*y+4)^2/8+(x-y+1)^2/27+15;
  o3=1/(x^2+y^2+1)-1.1*exp(-x^2-y^2)+0.1;

  obj(hjj,:)=[o1 o2 o3];
  c(hjj,:)  = 1;  
  
end





