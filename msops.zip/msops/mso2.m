%
% mso2.m Multiple Single Objective EA
%
% Multi-objective optimisation using multiple single objectives
%
% uses L^p norm approach.  Weight vector represents aim points.
%
% E.J.Huughes 23/4/2003
%

%% parameters common to all EAs

p=200;          % population size
f_obj='objmocons';  % objective function
maxgen=50;     % maximum number of generations


%% parameters for this technique

F=0.7;         % reduction factor
C=0.5;         % crossover rate

k=2;           % power for lp metric

ub=[1 1];    % upper bound on genes
lb=[0 0];  % lower bound on genes

wts=0:0.1:1;   % weight spread in nobj-1 dimensions
wmtx=[wts' 1-wts']*.3; % weight matrix - fixed for 2 objectives

wmtx=[wmtx;.115 .275];

%% Main code

[nobj,ncons]=feval(f_obj);  % get number of objectives and constraints

nwt=size(wmtx,1);   % number of weights

bnd=[ub;lb];   % bound array

%% initialise population and variables

if(C<0 | C>1 | F<0 | F>1 )
  disp('Error in C or F')
  F=0.7;
  C=0.5;
end

rng=bnd(1,:)-bnd(2,:);      % range of each gene
 
nvar=size(bnd,2);           % number of variables
  
pr=C.^(0:nvar-1);           % PDF for exponential crossover

chrom=rand(p,nvar).*(ones(p,1)*rng)+ones(p,1)*bnd(2,:);
                            % initial pop. lb<= x <=ub

gen=0;                      % generation counter
bst=nan*zeros(maxgen,nvar+2*nobj); % stores [mean(obj) min(obj) chrom]

[obj,cons]=feval(f_obj,chrom);     % evaluate initial pop.

%% Main loop

while(gen<maxgen)

  chx=zeros(p,nvar);   % create storage space for new chrom

  % do differential evolution recombination
  % first choose three other chromosomes
  for i=1:p

    r=1:p;                     % enumerate all possibilities
    r(i)=[];                   % exclude this one
    [fx,ii]=sort(rand(1,p-1)); % generate scrambled list
    r=r(ii);                   % scramble order
    
    chx(i,:)=chrom(i,:);       %copy of chromosome

    %DE/rand/1/exp

    n=floor(rand*nvar);       % place to start crossover
    l=max(find(pr>=rand));    % number to cross
    j=mod(n:(n+l-1),nvar)+1;  % indii of genes to cross
    chx(i,j) = chrom(r(1),j)+F*(chrom(r(2),j)-chrom(r(3),j)); % DE/rand/1/exp
  end
  
  rr=ones(p,1)*bnd(1,:);                 % matrix of upper limits
  chx(chx>rr)=rr(chx>rr);                % crop to upper range
  rr=ones(p,1)*bnd(2,:);                 % matrix of lower limits
  chx(chx<rr)=rr(chx<rr);                % crop to lower range
                                         
                                         
  [objx,consx]=feval(f_obj,(chx));       % evaluate objectives  

  objx=[obj;objx];                       % concatenate old obj with new
  consx=[cons;consx];                    % concatenate old constraint with new


  %% apply constraints
  tt=max(obj);                           % worse-case for constrained
  objxx=objx;                            % copy objectives
  tt=tt(ones(size(objx,1),1),:)+(2-consx(:,ones(1,nobj)));            
  objxx(consx<1,:)=tt(consx<1,:);        % mask off constrained solutions
  
  % generate multi-objective ranking
  nrx=zeros(size(objxx,1),nwt);
  for nx=1:size(objxx,1)
    nrx(nx,:)=sum((objxx(nx*ones(nwt,1),:)-wmtx).^k')+randn(1,nwt)*1e-10; % l-p metric
  end
  
  
  [a,ii]=sort(nrx);                      % get order of results
  tt=(1:size(objx,1))';
  for nx=1:nwt
    ii(ii(:,nx),nx)=tt;                  % give correct rank index
  end
  
  
  sv=sort(ii')';                        % sort to get score vector
%  [a,i]=sortrows(sv(:,1:2));            % get population rank order
  [a,i]=sortrows(sv);            % get population rank order
  
  obj=objx(i(1:p),:);                    % take best `p' objectives
  chx=[chrom;chx];                       % concatenate old & new chroms
  chrom=chx(i(1:p),:);                   % take best `p' chromosomes
  cons=consx(i(1:p),:);                  % take best `p' chromosomes
  
  gen=gen+1;                             % increment counter
  bst(gen,:)= [mean(obj) obj(1,:) chrom(1,:)]; % store mean & best
  pltres(gen,chrom,lb,ub,obj,bst);   % plot output graphs
  
  figure(2)
  v=axis;
  hold on
  plot(wmtx(:,1),wmtx(:,2),'r*')
  hold off
  axis(v)
  drawnow
  
end % end of main loop

figure(10)
plot(1:size(bst,1),bst(:,1:nvar)) % plot mean and best
xlabel('generation')

[obj(1) chrom(1,:)]               % output results
   

