% objmo4.m  Objective function 
%
% Fonseca 2 objective and constrained.
% 
% Minimise objectives
% Minimise constraints (zero = unconstrained)
%
% lower/upper bound on n genes [0,1]
%
% E.J.Hughes 22/5/2003



function [obj,c,ub,lb]=objmo4(Chrom,flaag)

nobj=4;                           % 4 objectives
ncons=1;                          % 1 constraint 

ub=[1 1];  % upper bound on genes
lb=[0 0];  % lower bound on genes

if nargin==0
  obj=nobj;
  c=ncons;
  return;
end


[popsize,nvar]=size(Chrom);


% Loop for all chromosomes 

obj=zeros(popsize,nobj);          % space for objectives
c  = ones(popsize,1);             % all unconstrained

for hjj=1:popsize

  chrom=Chrom(hjj,:)*4-2;  % 0-1 now -2 to 2

  %% Calculate objectives

  o1=1-exp(-sum((chrom-1/sqrt(nvar)).^2));
  o2=1-exp(-sum((chrom+1/sqrt(nvar)).^2)); %fonseca 2 objective

  chrom=Chrom(hjj,:) * pi;  % 0-1 now 0 to pi

  x=chrom(1);
  y=chrom(2);
  
  %% Calculate objectives

  o3=x/pi;
  o4=y/pi;

  
  c1 = 0>= -(x^2) - (y^2) +1 + 0.1 * cos(16 * atan2(y,x));
  c2 = 0.5>= (x-0.5)^2 + (y-0.5)^2;
  
  c(hjj,:)  = sqrt(c1*c2);   % geometric mean of constraints

  
  obj(hjj,:)=[o1 .535*o2 o3 o4];    % objective vector
  
end





