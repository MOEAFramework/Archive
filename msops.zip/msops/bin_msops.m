%
% bin_msops.m
%
% Binary chop optimisation
% with multiple single objective pareto sampling
%
% Global and local search with size restriction
% does extended local search if size restriction 
% encountered.
%
% local search is based on min distance.
%
%
% E.J.Hughes 19/9/2002
%
% updated 27/9/2004

function [po,pc,obj,chrom,trl] = bin_msops()

%rand('state',41);
%randn('state',ceil(rand*100000));  % seed simulation

global pareto_points chrom trx obj con minarea nvar limu liml lsch pdist
tic

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameters to set up for optimiser ...

tv=[];          % default target vector set - cover entire region

% example constrained 2 objective problem
% use default target definition first to do full exploration of space, then uncomment targets
f_obj='objmocons';ooff=[0 0];  % 2 objective function

%example of 4 objectives - solution appears to lie on a line
%f_obj='objmo4';ooff=[0 0 0 0];  % 4 objective function
% figure 3 is a screw up!

% highly constrained 2 objective
%f_obj='nobj1';ooff=[0 0];  % objective function, 2 obj, highly constrained
% figure 3 is a screw up!


[nobj,ncon,ub,lb]=feval(f_obj);  % get number of objectives and constraints and genes
                           %(1 constraint assumed by rest of code)
%ooff=[0 0];         % 'to be subtracted off' offset for objectives - objectives must be +ive

maxgen=250;         % maximum number of samples to take
gflaag=1;           % =1 for verbose plotting, 0 for minimal
fgg=0;              % set to 1 to start printing plots

nwt=30;   % number of weight vectors

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% parameters for this technique - unlikely to need modification
localpareto=0;      % 1 for local pareto, 0 for global
tsize=100;          % tournament size
minarea=0.01^2;     % minimum cell area
pdist=0.1;         % \pm search distance
K=0.04;             % half range point in search shaping curve
si=0.1;             % spread of shaping curve
C=0.06;             % final global search value
Kvads=100;          % power to raise cos \theta


%% Main code
disp('Generating weight vectors')
if(isempty(tv)) tv=nobj; end
wts=vspace(nwt,tv);   % create target weight vector set for msops.


t=0:0.01:1;
a0=tanh(-K/si);
a1=tanh((1-K)/si);
p=(tanh((t-K)/si)-a0)/(a1-a0)*(C-1)+1; 
figure(10)
plot(t*maxgen,p);grid
axis([0 maxgen 0 1])
xlabel('trial number')
ylabel('probability of global search')

%% initialise population and variables

bnd=[ub;lb];                % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene

nvar=size(bnd,2);           % number of variables

gen=1;                      % point counter - next empty slot
nmisses=0;                  % number of local misses
lsch=0;                     % number of lsearch2
src=0;
ptr=0;                      % previous node and branch

ru=ones(1,nvar)*inf;
rl=-ones(1,nvar)*inf;       %initial box bounds

trx=zeros(maxgen,5); % storage for tree [Pl Pu Al Au cut_axis]
limu=zeros(maxgen,nvar); % storage for upper limits
liml=zeros(maxgen,nvar); % storage for lower limits

chrom=zeros(maxgen,nvar);      % storage for chromosomes
obj  =zeros(maxgen,nobj);      % storage for objectives
con  =zeros(maxgen,1);         % storage for constraints

disp('Running ..')
%% Main loop
while(gen<=maxgen)


  % generate new point
  chromx=randn(1,nvar)/8+0.5;           % Gaussian point
  %chromx=0.5*ones(1,nvar);           % Gaussian point
  chromx=max([zeros(1,nvar);chromx]);
  chromx=min([ones(1,nvar);chromx]); %crop to box
  rlx=max([zeros(1,nvar);rl]);
  rux=min([ones(1,nvar);ru]);        %crop to box
  chromx=chromx.*(rux-rlx)+rlx;     %scale to region
  chromy=chromx.*rng+bnd(2,:);     % scale to problem
  
  [tobj,tcon]=feval(f_obj,chromy); % evaluate initial pop. tcon=1 if valid
  tobj=tobj - ooff;
  
  %tcon=1; for satisfies constraint
  
  % store in tree

  chrom(gen,:)=chromx;             % store chromosome
  obj(gen,:)=tobj;                 % store objective
  con(gen,:)=tcon;                 % store constraint

  % link to tree
  trx(gen,1:2)=0;                  % show leaf
  if(src)
    trx(src,ptr)=gen;              % link to tree if not root node
  end

  % find best place to cut
  ars=zeros(2,nvar);               % storage for areas, 1=lower, 2=upper
  rto=zeros(2,nvar);               % storage for size ratio
  
  
  for n=1:nvar
    % create lower cell
    ruxt=rux;
    ruxt(n)=chrom(gen,n);          % modify upper bound only
    dff=abs(ruxt-rlx);             % axis widths
    rto(1,n)=max(dff)/(min(dff)+1e-30);    % ratio
    ars(1,n)=prod(dff);            % area

    % create upper cell
    rlxt=rlx;
    rlxt(n)=chrom(gen,n);          % modify lower bound only
    dff=abs(rux-rlxt);             % axis widths
    rto(2,n)=max(dff)/(min(dff)+1e-30);    % ratio
    ars(2,n)=prod(dff);            % area
  end

  [a,ii]=max(ars);                  % find largest cells
  [a,i]=min(diag(rto(ii,:)));       % find smallest ratio

  trx(gen,5)=i;                    % cut plane
  trx(gen,3:4)=ars(1:2,i)';        % areas

  limu(gen,:)=rux;
  liml(gen,:)=rlx;

  gen=gen+1;                       % indicate next slot

  scc=sum(con>0);

  % generate probability of global or local search
  t=gen/maxgen;
  a0=tanh(-K/si);
  a1=tanh((1-K)/si);
  p=(tanh((t-K)/si)-a0)/(a1-a0)*(C-1)+1; 

  % global or local search
  %if(rand<(1-gen/maxgen)^6 | ~scc) % random or if no valid
  if(rand<p | ~scc) % random or if no valid
    [src,ptr,tt]=gsrch;              % find largest
  
  else
 
    nnx=1:maxgen;
    nnx=nnx(con>0);   % find only those that meet constraints
    stk=min([tsize scc]);  % tournament size  
    [ftx,fii]=sort(rand(1,scc));
    fii=fii(1:stk);                % choose members for tournament
       
    if(localpareto)
      % local pareto
      r=msorank(obj(nnx(fii),:),zeros(length(fii),1),wts,Kvads);     % generate tournament pareto set
      %r=pareto(obj(nnx(fii),:));     % generate tournament pareto set
      %r=1-nondom(-obj(nnx(fii),:),chrom(nnx(fii),:),share);% tournament set
      %r=1-nondom(-obj(nnx(fii),:),obj(nnx(fii),:),share);% tournament set
      [ftx,ii]=min(r);               % get best
    else
      % global pareto
      r=msorank(obj(con>0,:),zeros(sum(con>0),1),wts,Kvads);     % generate tournament pareto set
      %r=pareto(obj(con>0,:));     % generate viable pareto set
      %r=1-nondom(-obj(con>0,:),chrom(con>0,:),share); % generate viable set
%      r=1-nondom(-obj(con>0,:),obj(con>0,:),share); % generate viable set

      rra=max(trx(con>0,3:4)')';     % get largest associated areas       
      [ta,ti]=sort(-rra);            % sort to get largest areas
      r=r+ti;                        % non-parametric weighted sum
      
      [ftx,ii]=min(r(fii,:));        % get good and near large area
     
  end
  
    ii=nnx(fii(ii));               % index to best chromosome
  
    [src,ptr,tt,ar]=lsrch2(ii);    % enhanced local search 
    
       
    if(ar<minarea)                  % if region too small,
      [src,ptr,tt]=elsrch(ii);      % extended local search instead
      nmisses=nmisses+1;
    end    
    
  end

  
  rl=tt(2,:);                      % update region to seach next    
  ru=tt(1,:);                      %
  
  if(gflaag)
    
    figure(1)
    % plot chromosome
    %  chromy=chromx.*rng+bnd(2,:);     % scale to problem
    
    if(nvar<=2)
      [dta,dtb]=gplot;
      plot(dta(:,1),dta(:,2),dtb(:,1),dtb(:,2),'x')
      %axis([0 1 0 1])
      grid
    else
%      plot(chrom(:,1),chrom(:,2),'.');grid
      plot(chrom');grid
    end
    title('Chromosomes')
    
	figure(2)
    %plot objectives
	if(sum(con>0))
  	  nnx=1:maxgen;
     nnx=nnx(con>0);
     r=pareto(obj(con>0,:));
     pf= obj(nnx(r==1),:);
     cf=obj(con>0,:);
   else
     disp('no valid solutions!')
     pf=min(obj);
     cf=pf;
   end
   plot(obj(:,1),obj(:,2),'g.',cf(:,1),cf(:,2),'b.',pf(:,1),pf(:,2),'rx')
   %axis([0 1 0 1])
   grid
   title('objective and pareto sets')

   figure(3)
   [dta,dtb]=gplot;
   if(sum(con>0))
      nnx=1:maxgen;
      nnx=nnx(con>0);
      r=pareto(obj(con>0,:));
      pf= obj(nnx(r==1),:);
      cf=obj(con>0,:);
    else
      disp('no valid solutions!')
      pf=min(obj);
      cf=[0 0];
    end
    plot(dta(:,1),dta(:,2),'b-',obj(:,1),obj(:,2),'g.',cf(:,1),cf(:,2),'b.',pf(:,1),pf(:,2),'rx')
    axis([0 1 0 1])
     xlabel('Objective 1','fontsize',8)
     ylabel('Objective 2','fontsize',8)
     title([num2str(size(dtb,1)) ' evaluations'],'fontsize',8)
     set(gca,'fontsize',8)
    grid
    
    drawnow

    set(2,'PaperUnits','centimeters','PaperPosition',[1 1 10 8]);
    if(fgg)
      eval(['print -f2 -djpeg95 figs/img' num2str(fgg) '.jpg']);
      fgg=fgg+1;
    end

    %gen
  end

end

%% end of run, return results

toc



figure(1)
%  chromy=chromx.*rng+bnd(2,:);     % scale to problem

if(nvar<=2)
  [dta,dtb]=gplot;
  plot(dta(:,1),dta(:,2),dtb(:,1),dtb(:,2),'x')
  axis([0 1 0 1])
  grid
else
  plot(chrom(:,1),chrom(:,2),'.');grid
end


%figure(2)
%plot(chrom(:,1),chrom(:,2),'x')
%axis([0 1 0 1])
%grid

figure(2)
if(sum(con>0))
  nnx=1:maxgen;
  nnx=nnx(con>0);
  r=pareto(obj(con>0,:));
  pf= obj(nnx(r==1),:);
  cf=obj(con>0,:);
else
  disp('no valid solutions!')
  pf=min(obj);
end
plot(obj(:,1),obj(:,2),'g.',cf(:,1),cf(:,2),'b.',pf(:,1),pf(:,2),'rx')
%axis([0 1 0 1])
grid

drawnow

nmisses
lsch

pset_num=sum(r==1)

  % find how many discrete points
  h=obj(con>0,:);
  h=h(r==1,:);        % pareto obj
  po=h+ooff(ones(size(h,1),1),:);
  pc=chrom(r==1,:);   % pareto chroms
   p=sortrows(h);
   msk=(p(1:end-1,:)-p(2:end,:));
   ii=[1;sum(abs(msk')>0)'>0];          
   h=h(logical(ii),:);

   pareto_points=sum(ii)

	obj=obj+ooff(ones(size(obj,1),1),:);
	
	
	
%plot(0,0)
%hold on
%for n=1:length(chrom)
%  plot(dta(1+(n-1)*3:n*3,1),dta(1+(n-1)*3:n*3,2),dtb(n,1),dtb(n,2),'x')
%  axis([0 1 0 1])
%  drawnow
%  pause
%end
%hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal functions


function [a,b]=gplot(n,lim)

global plt pp chrom trx nvar

if(nargin==0)
  plt=[];
  pp=[];
  lim=[ones(1,nvar);zeros(1,nvar)];
  n=1;
end

a=[];
% do this node
tmp1=lim(1,:);
tmp2=lim(2,:);
tmp1(trx(n,5))=chrom(n,trx(n,5));
tmp2(trx(n,5))=chrom(n,trx(n,5));
plt=[plt;tmp1;tmp2;ones(1,nvar)*nan];
pp=[pp;chrom(n,:)];
% check left
if(trx(n,1))
  ll=lim;
  ll(1,trx(n,5))=chrom(n,trx(n,5));  % crop upper bound
  gplot(trx(n,1),ll);  % left  
end

% check right
if(trx(n,2))
  ll=lim;
  ll(2,trx(n,5))=chrom(n,trx(n,5));  % crop lower bound
  gplot(trx(n,2),ll);  % right
end
  
if(n==1)
  a=plt;
  b=pp;
end
  

function [src,ptr,rgn]=gsrch(n,lim)

global chrom trx mxf src ptr rgn nvar

if(nargin==0)
  lim=[ones(1,nvar);zeros(1,nvar)];
  n=1;
  mxf=-1;
  src=0;
  ptr=0;
  rgn=lim;
end

% do this node

% check left
ll=lim;
ll(1,trx(n,5))=chrom(n,trx(n,5));  % crop upper bound
if(trx(n,1))             % if not leaf 
  if(trx(n,3)>mxf)       %and could have larger area,
    gsrch(trx(n,1),ll);  % left  
%  else disp ('prune left')
  end
else
  if(mxf<trx(n,3))
    mxf=trx(n,3);
    src=n;
    ptr=1;
    rgn=ll;
  end
end

% check right
ll=lim;
ll(2,trx(n,5))=chrom(n,trx(n,5));  % crop lower bound
if(trx(n,2))             % if not leaf 
  if(trx(n,4)>mxf)       %and could have larger area,
    gsrch(trx(n,2),ll);  % right
%  else disp ('prune right')
  end
else
  if(mxf<trx(n,4))
    mxf=trx(n,4);
    src=n;
    ptr=2;
    rgn=ll;
  end
end  


function [src,ptr,rgn,mxf]=lsrch(p,n,lim)

global chrom trx mxf src ptr rgn nvar

if(nargin==1)
  lim=[ones(1,nvar);zeros(1,nvar)];
  n=1;
  mxf=-1;
  src=0;
  ptr=0;
  rgn=lim;
end

% do this node

% check left
ll=lim;
ll(1,trx(n,5))=chrom(n,trx(n,5));  % crop upper bound
if(chrom(n,trx(n,5)) >= chrom(p,trx(n,5))) %if is viable 
  if(trx(n,1))        % if not leaf 
    lsrch(p,trx(n,1),ll);  % left  
  else
    if(mxf<trx(n,3))
      mxf=trx(n,3);
      src=n;
      ptr=1;
      rgn=ll;
    end
  end
end

% check right
ll=lim;
ll(2,trx(n,5))=chrom(n,trx(n,5));  % crop lower bound
if(chrom(n,trx(n,5)) <= chrom(p,trx(n,5))) %if is viable
  if(trx(n,2))        % if not leaf 
    lsrch(p,trx(n,2),ll);  % right
  else
    if(mxf<trx(n,4))
      mxf=trx(n,4);
      src=n;
      ptr=2;
      rgn=ll;
    end
  end  
end


function [src,ptr,rgn]=elsrch(p,n,lim)

global chrom trx mxf src ptr rgn minarea nvar

if(nargin==1)
  lim=[ones(1,nvar);zeros(1,nvar)];
  n=1;
  mxf=1e10;
  src=0;
  ptr=0;
  rgn=lim;
end

% do this node

% check left
ll=lim;
ll(1,trx(n,5))=chrom(n,trx(n,5));  % crop upper bound
if(trx(n,1))             % if not leaf 
  if(trx(n,3)>minarea)       % and could have large enough area,
    elsrch(p,trx(n,1),ll);  % left  
%  else disp ('prune left')
  end
else
  if(trx(n,3)>minarea)  % if cell large enough
    dst=chrom(p,:)-(ll(1,:)+ll(2,:))/2;
    dst=dst*dst'; % distance squared from point to centre of cell
    if(mxf>dst)   
      mxf=dst;    % if cell better, take it
      src=n;
      ptr=1;
      rgn=ll;
    end
  end
end

% check right
ll=lim;
ll(2,trx(n,5))=chrom(n,trx(n,5));  % crop lower bound
if(trx(n,2))             % if not leaf 
  if(trx(n,4)>minarea)       %and could have large enough area,
    elsrch(p,trx(n,2),ll);  % right
%  else disp ('prune right')
  end
else
  if(trx(n,4)>minarea)  % if cell large enough
    dst=chrom(p,:)-(ll(1,:)+ll(2,:))/2;
    dst=dst*dst'; % distance squared from point to centre of cell
    if(mxf>dst)   
      mxf=dst;    % if cell better, take it
      src=n;
      ptr=2;
      rgn=ll;
    end
  end
end  


function [src,ptr,rgn,mxf]=lsrch2(p,n,lim)

global chrom trx mxf src ptr rgn nvar limu liml lsch pdist

if(nargin==1)
  lim=[ones(1,nvar);zeros(1,nvar)];
  n=1;
  mxf=-1;
  src=0;
  ptr=0;
  rgn=lim;
  lsch=lsch+1;
end



% do this node

% check left
ll=lim;
ll(1,trx(n,5))=chrom(n,trx(n,5));  % crop upper bound
%if(chrom(n,trx(n,5)) >= chrom(p,trx(n,5))) %if is viable 
flaag=1;
for r=1:nvar
%  if(ll(2,r) > limu(p,r) ...
%     | ll(1,r) < liml(p,r))  % check limits on areas
  if(ll(2,r) > chrom(p,r)+pdist ...
     | ll(1,r) < chrom(p,r)-pdist)  % check limits on areas
    flaag=0;  % no overlap of regions
    break;
  end
end
if(flaag)
%  disp('passed!')
  if(trx(n,1))        % if not leaf 
    lsrch2(p,trx(n,1),ll);  % left  
  else
    if(mxf<trx(n,3))
      mxf=trx(n,3);
      src=n;
      ptr=1;
      rgn=ll;
    end
  end
end

% check right
ll=lim;
ll(2,trx(n,5))=chrom(n,trx(n,5));  % crop lower bound
%if(chrom(n,trx(n,5)) <= chrom(p,trx(n,5))) %if is viable
flaag=1;
for r=1:nvar
%  if(ll(2,r) > limu(p,r) ...
%     | ll(1,r) < liml(p,r))
   if(ll(2,r) > chrom(p,r)+pdist ...
      | ll(1,r) < chrom(p,r)-pdist)  % check limits on areas
    flaag=0;
    break;
  end
end
if(flaag)
  if(trx(n,2))        % if not leaf 
    lsrch2(p,trx(n,2),ll);  % right
  else
    if(mxf<trx(n,4))
      mxf=trx(n,4);
      src=n;
      ptr=2;
      rgn=ll;
    end
  end  
end
  
function [rnk]=msorank(obj,cons,wmtx,K);

%K=100;         % power to raise cos \theta

[nwt,nobj]=size(wmtx);   % number of weights and objectives

  %% apply constraints
  tt=max(obj);                           % worse-case for constrained
  objxx=obj;
  tt=tt(ones(size(obj,1),1),:)+cons(:,ones(1,nobj));            
  objxx(cons>0,:)=tt(cons>0,:);        % mask off constrained solutions
  
  % generate multi-objective ranking
  nrx=zeros(size(objxx,1),nwt);
  nrxwmm=zeros(size(objxx,1),nwt);
  for nx=1:size(objxx,1)
    magn=sqrt(sum(objxx(nx*ones(nwt,1),:)'.^2))+1e-30; % magnitude of objectives
    csn =sum((objxx(nx*ones(nwt,1),:).*wmtx)')./magn; % cos \theta
    csn(csn>1)=1; % prevent numerical error
    nrx(nx,:)=  magn./(csn.^K+1e-2)+randn(1,nwt)*1e-10; % vector weighted magnitude.
%    nrx(nx,:)=  acos(csn)*180/pi+randn(size(csn))*1e-2; % angle only
  
     nrxwmm(nx,:)=max((objxx(nx*ones(nwt,1),:)./(wmtx+1e-30))')+randn(1,nwt)*1e-10; % weighted min-max
  end

  tt=1:nwt;                                % index vector
  [a,iimm]=sort(nrxwmm);                   % get order of results
  [a,ii]=sort(nrx);                        % get order of results

  
  tt=(1:size(obj,1))';
  i2=ii;
  im2=iimm;
  for nx=1:nwt
    ii(i2(:,nx),nx)=tt;                 % give correct rank index
    iimm(im2(:,nx),nx)=tt;              % give correct rank index
  end
  
  sv=sort([ii iimm]')';                  % sort to get score vector
%  sv=sort([iimm]')';                  % sort to get score vector
  [a,i]=sortrows(sv);                    % get population rank order
  
  rnk=i;
  rnk(i)=tt;                             % give correct ranks out.
  



