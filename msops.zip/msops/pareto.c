/*

  Pareto.C	 .MEX file for finding Pareto optimal sets.

  The calling syntax is:

                        ranking = pareto(objectives)

  where
         objectives=[x1 y1 .. z1;
                     x2 y2 .. ..;
                      .  . .. .. 
                      .  . .. ..
                     xn yn .. zn];

            ranking=[r1;
                     r2;
                      .
                      .
                     rn];  rank of 1 are best.
                      
  E.J.Hughes   April 18 1997

   updated for matlab6 June 13 2002 

*/

#include <math.h>
#include <stdlib.h>
#include <mex.h>


/* Input Arguments */

#define	T_IN	prhs[0]


/* Output Arguments */

#define	R_OUT	plhs[0]

#define ULINT unsigned long int
#define OBJ(node,objective) p_data[((node)-1)+((objective)*no_obj)]
#define NEXT(n)             p_index[(n)*2]
#define FITN(n)             p_index[(n)*2+1]

ULINT *p_index,no_obj,x_siz,n_cnt;
double *p_data;


void AddNode(t_this,t_prev,fitness)
     ULINT t_this,t_prev,fitness;
{
  NEXT(t_this)=NEXT(t_prev);
  NEXT(t_prev)=t_this;
  FITN(t_this)=fitness;
  n_cnt++;
}

void DelNode(t_node,t_prev_node)
     ULINT t_node,t_prev_node;
{
  NEXT(t_prev_node)=NEXT(t_node);
  NEXT(t_node)=0;
  FITN(t_node)=0;
  n_cnt--;
}

void Check(t_this,fitness)
     ULINT t_this,fitness;
{
 
  ULINT cnt1,cnt2,n,t_node,t_prev;
  t_prev=0;
  t_node=NEXT(0);   /* start of layer(0) - working layer */
  cnt1=1;cnt2=0;
  while((t_node)&&(cnt1)) /* stop if t_this is dominated by t_node */
    {
      cnt1=0;cnt2=0;
      
      for (n=0;n<x_siz;n++)
	{
	  if(OBJ(t_this,n)<=OBJ(t_node,n)) cnt1++; /* compare */
	  if(OBJ(t_this,n)>=OBJ(t_node,n)) cnt2++; /* compare */
	}
      if ((cnt1==x_siz)&&!(cnt2==x_siz)) 
	{
	  DelNode(t_node,t_prev); /* t_this dominates */
	  t_node=t_prev;
	}         /* so cut t_node */
      
      if((cnt2==x_siz)&&!(cnt1==x_siz)) cnt1=0;      /* dominated by t_node*/
      t_prev=t_node;
      t_node=NEXT(t_node); /* next one */
    }
  if (cnt1) 
    AddNode(t_this,t_prev,fitness);  /* if end of line, add in */

  return;
}

void Pareto()
{
  ULINT t_this,fitness,n;

  fitness=1;

  for (n=0;n<=no_obj+1;n++)
    FITN(n)=0; /* setup to show un-allocated */

  do
    {

      t_this=0;
      n_cnt=0;
      NEXT(0)=0;              /* new layer */
      while(FITN(++t_this));  /* find first free item */

      while(t_this<=no_obj)
	{
	  Check(t_this,fitness);  /* update list */
	  while(FITN(++t_this));  /* parse free items */
	}

      fitness+=n_cnt;

      t_this=0;
      while(FITN(++t_this));  /* find first free item */
      
    }while(t_this<=no_obj);

	
  return;
}


void mexFunction(int nlhs,mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	
  ULINT m,n,curr,t_this,t_layer;
  double *p_out;

  /* Check for proper number of arguments */
   
  if (nrhs != 1) 
    mexErrMsgTxt("Pareto requires one input argument.");
  if (nlhs>1)
    mexErrMsgTxt("Pareto requires one output argument.");


  /* Check the dimensions of data.  can be  m x n  where n,m>=1*/

  m = mxGetM(T_IN);
  n = mxGetN(T_IN);
  

  if (!mxIsNumeric(T_IN) || mxIsComplex(T_IN) || !mxIsDouble(T_IN))
    mexErrMsgTxt("Pareto requires a double input array!");
  
  p_index=NULL;
  R_OUT=NULL;

  if ((m)&&(n))
    {  
      no_obj=m;
      x_siz=n;

      p_data = mxGetPr(prhs[0]);       

      if((p_index=(ULINT *)mxCalloc(2*no_obj+4,sizeof(ULINT)))==NULL)
	mexErrMsgTxt("Pareto alg. needs more memory");

      Pareto(); /* create index list */

      R_OUT = mxCreateDoubleMatrix(no_obj,1,mxREAL);    
      p_out = mxGetPr(R_OUT);
 
      if(p_index)
	{
	  for (n=1;n<=no_obj;n++)
	    p_out[n-1]=(double)FITN(n);
	  /*    p_out[n-1]=(double)no_obj-(double)FITN(n)+1; */

	  mxFree(p_index);
	}
    }
  return;
}


