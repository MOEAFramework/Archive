%
% findN.m  Finds Equivalent popsize for minimal hypercone angle onto
% hyperspere surface.
%
% N is no. of points,
% n is dimensions of shpere
% al is the smallest angle
% E.J.Hughes 13/12/2007

function N=findN(al,n)

if(n==2)
    N=pi/al;  % solution is trivial for 2D
    return;
end

if(mod(n,2)==0)
    j=0:(n-4)/2;
else
    j=0:(n-3)/2;
end

if(mod(n,2)==0)
    frac=1/pi*(al-cos(al)*sum(2.^(2*j).*factorial(j).^2./factorial(2*j+1).*sin(al).^(2*j+1)));
else
    frac=1/2*(1-cos(al)*sum(factorial(2*j)./factorial(j).^2./2.^(2*j).*sin(al).^(2*j)));
end

N=1/frac;    
    
    
        
        
        