%
% Angtest.m
%
% Tests that probability of misclassification as interior is correct
% when fingAng.m is applied.
%
% E.J.Hughes 2008
%% Test that the conversion to ratio from angle indeed does make the
% algorithm independent of the number of objectives, and compare
% Monte-carlo results to the analytic CDF equation.

objs=2:20;       % number of objectives to study
nxx=2.^(0:5);   % size of local search
ntrx=100         % number of monte-carlo trials to average
bq=zeros(length(objs),length(nxx),ntrx);   % used to record angles
rr=bq;
for jj=1:ntrx
    for kk=1:length(objs)
        for ff=1:length(nxx)
            nobj=objs(kk);        % number of objectives
            npts=30;              % number of points on sphere
            nxxq=nxx(ff);         % size of random search
            
            p=randn(npts+1,nobj);     
            lp=sqrt(sum(p.*p,2));
            p=p./lp(:,ones(1,nobj));  % uniform distribution on hypersphere
            
            p(1,:)=zeros(1,nobj);  % centre point as reference,
            
            [npop,nvar]=size(p);
            
            tv=zeros(size(p));
            q=zeros(npop,1);
            
            dv=p-p(ones(npop,1),:);  % difference vectors
            dv(1,:)=[];  % not this one
            d=sqrt(sum(dv.^2,2)); % length
            dv=dv./d(:,ones(nvar,1)); % unit length
            
            % do nxxq point random search of hypercones
            q(1)=inf;
            for m=1:nxxq
                vv=randn(1,nvar);      % random vector "m" initially
                vv=vv/sqrt(vv*vv');    % unit length
                h=dv*vv';  % dot product with all others on hypersphere
                [qt,i]=min(-h); % find closest set
                if(-qt(1)<q(1))
                    q(1)=-qt(1);
                    tv(1,:)=vv;   % record best of random search
                end
            end
            
            % analyse now, convert angle to ratio
            rr(kk,ff,jj)=1./findN(acos(q(1)),nobj);

            bq(kk,ff,jj)=q(1); % record data for calc of mean
        end
        [jj kk ff acosd(q(1))]
    end

    %plot image of hyperspherical cap ratios; image shows pattern that is
    %independent of the number of objectives, dependent only on the size of
    %the random search.
    figure(1)
    mq=squeeze(sum(bq,3))/jj;
    imagesc(log2(nxx),objs,mq)  % plot image of ratios
    colorbar
    xlabel('Log_{10}(number of random trials)')
    ylabel('Number of objectives')
    title('observed max angle cosine (independent of N_{obj})')
    drawnow

    figure(2)
    mq=squeeze(sum(rr,3))/jj;
    imagesc(log2(nxx),objs,mq)  % plot image of ratios
    colorbar
    xlabel('Log_{10}(number of random trials)')
    ylabel('Number of objectives')
    title('Calculated ratio of hypercap area (independent of N_{obj})')
    drawnow

end

%%
alph=0.9;
limx=zeros(length(objs),length(nxx));   % used to record limit angles
rx=limx;
for kk=1:length(objs)
    for ff=1:length(nxx)
        [limx(kk,ff),rx(kk,ff)]=findang(nxx(ff),npts,objs(kk),alph); %angle for 90% limit
    end
end

aq=limx*180/pi;
zq=acos(bq)*180/pi;

hx=zeros(length(objs),length(nxx));   % used to record probs
for kk=1:length(objs)
    for ff=1:length(nxx)
        hx(kk,ff)=sum(zq(kk,ff,:)<aq(kk,ff))/ntrx; %angle for 90% limit
    end
end

hx  
mean(hx) % should be all about 90%

%%
zx=zeros(length(objs),length(nxx));   % used to record probs
zr=zx;
for kk=1:length(objs)
    for ff=1:length(nxx)
        zx(kk,ff)=prctile(zq(kk,ff,:),alph*10); %angle for 90% limit
        zr(kk,ff)=prctile(rr(kk,ff,:),alph*10); %angle for 90% limit
    end
end

zx
zr