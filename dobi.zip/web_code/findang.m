%
% findang.m  Finds minimal hypercone angle for given number of points on
% hyperspere surface.
%
% Nsamp is no. of attempts used in random search,
% Npop is the number of points local to point under test being considered
%   for angles
% nobj is dimensions of shpere
% 1-Plim is the probability of classifying and interior point as exterior.
% E.J.Hughes 12/12/2007

function [al, r]=findang(Nsamp, Npop, nobj, Plim)

if(nargin==3)
    Plim=0.95;  % 5% chance of not rejecting surrounded point
end
% first need to calculate the area ratio that we would expect
% from a surrounded point

% binary chop to find ratio; if no. of samples too small, return NaN
ru=1;
rl=0;
r=(ru+rl)/2;
err=1;
cnt=0;
while(abs(err)>1e-6)
    %[ru r rl]
    F=ratio_cdf(r, Nsamp, Npop);
    err=Plim-F;
    if(err>0)
        rl=r;
    else
        ru=r;
    end
    r=(ru-rl)/2+rl;
    cnt=cnt+1;
    if(cnt>400)
        %disp('error in binary search of ratio')
        %[ru r rl]
        r=NaN;
        break;
    end
end

frac=r;  % 1/r is equivalent number of points on uniform hypersphere

% need to convert ratio into angle next.
alu=2*pi;
all=0;
al=(alu+all)/2;
err=1;

if(nobj==2)
    al=frac*pi;  % solution is trivial for 2D
    return;
end

if(mod(nobj,2)==0)
    j=0:(nobj-4)/2;
else
    j=0:(nobj-3)/2;
end
% binary chop to find angle
cnt=0;
while(abs(err)>1e-6)
    %[alu al all]*180/pi;
    if(mod(nobj,2)==0)
        err=frac-1/pi*(al-cos(al)*sum(2.^(2*j).*factorial(j).^2./factorial(2*j+1).*sin(al).^(2*j+1)));
    else
        err=frac-1/2*(1-cos(al)*sum(factorial(2*j)./factorial(j).^2./2.^(2*j).*sin(al).^(2*j)));
    end

    if(err>0)
        all=al;
    else
        alu=al;
    end
    al=(alu-all)/2+all;
    cnt=cnt+1;
    if(cnt>400)
        %disp('error in binary search of angle')
        al=NaN;
        break;
    end
end
    
    
    
function F=ratio_cdf(al,Nsamp, Npop)

F=0;
for hh=0:(Nsamp-1)
    F=F+Nsamp*nchoosek(Nsamp-1,hh)*(-1)^hh/(1+hh)*(1-exp(-Npop*al*(hh+1)));
end
        
        
        