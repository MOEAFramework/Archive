%
% sort_pop.m  Performs objective front based sort.
% uses in/out criteria to sort preferred to non-preferred
% index gives exterior first, then interior then constrained.
%
% E.J.Hughes 14/11/2007
function [i,c,shd,q]=sort_pop(o,c,shd,sflaag)
global gen eqn
if(nargin<4)
    sflaag=0;  % do minimisation of all objectives rather than min&max
end

nsamp=10;    % number of random angle samples to take. (N_s in paper)
Nmax=25;     % number in local point neighbourhood (N_l in paper)
plim=0.95;   % 1-plim will give probability of not rejecting surrounded point (\alpha in paper)

bt=0.001;  % share 'standard deviation'
%%
if(nsamp<5)
    disp('random sample size too small, adjusting')
    nsamp=7;
end
if(Nmax<nsamp*2)
    disp('local size too small for number of random samples, adjusting')
    Nmax=nsamp*2+1
end

[npop,nobj]=size(o);

cval=sum(c(:,1:end-1)<0,2)==0;   % true if valid, inside/outside not considered
nval=sum(cval);      % new solutions that do not have shares yet
ot=o;

sumvec=zeros(sum(cval),nobj); % sum of weighted vectors
shdist=zeros(sum(cval),1); % sum of share distances
tv=zeros(sum(cval),nobj);
shdx=zeros(sum(cval),1);
q=-ones(sum(cval),1);    % default to 180 degrees in case very few.
aaa=zeros(sum(cval),1);    % default to 180 degrees in case very few.

o=ot(cval,:);     % just do angle of valid ones.

% normalise objectives into unit box space (valid ones only) to 
% make sure that Euclidian distances are sensible when calculated 
% in the higher dimensional spaces.
mzw=min(o);
xzw=max(o);       % upper/lower bounds
rrx=(xzw-mzw);     % ranges to use for normalisation
o=o-mzw(ones(sum(cval),1),:);
o=o./rrx(ones(sum(cval),1),:);% unit size box region for testing

mskx=c(cval,end);  % get in/out details
msk=mskx>0 | (1+mskx)>=rand(size(mskx)) ; % flaag if outside or not necessarily inside
if(sum(msk)>2)
    for n=find(msk)'
        dv=o-o(n*ones(sum(cval),1),:);  % difference vectors to valid.
        d2=sum(dv.^2,2); % length squared      
        kk=min(Nmax+1,sum(cval)); % all or top N (self will be removed)
        
        [a,i]=sort(d2);  % sort by distance
        dv=dv(i(2:kk),:);
        d2=d2(i(2:kk),:);  % just nearest kk neighbours, but not self
        d=sqrt(d2); % length
        dv=dv./d(:,ones(nobj,1)); % unit length
        % update share distances first

        shdx(n)=sum(exp(-d2/bt/2)); % share distance to nearest set    
        
        % random search
        q(n)=2;
        for m=1:nsamp
            if(~sflaag)
                vv=-abs(randn(1,nobj)); % random search, but all minimise
            else
                vv=randn(1,nobj);      % random search, all directions
            end
            vv=vv/sqrt(vv*vv'); % unit length
            h=dv*vv';  % dot product
            [qt,i]=sort(-h); % find closest set - cos(\theta) so max to min \theta
            
            if(-qt(1)<q(n))
                q(n)=-qt(1);
                tv(n,:)=vv;
            end
        end
           aaa(n)=1./findN(acos(q(n)),nobj);  % ratio
    end
else
    q(cval)=-1;  % if only few valid, make look like 180 degrees!
end
%%
h=.25;

itmp=1:npop;  % want all eventually
itmp=itmp(cval); % indices of good solutions.
itmp=itmp(msk);  % indices of updated solutions.
shd(itmp)=shdx(msk);  % paste share values back in

[a,i]=sort(-aaa./(1+shdx));  % shared ratios of good solutions

ii=1:sum(cval);
ii(i)=sum(cval)-ii;    % reverse rank order of solutions based on share ratio
m=tv*(-ones(nobj,1))<0;  % find those pointing away from nominal search direction

% handle constrained now
itmp=1:npop;  % want all eventually
itmp=itmp(cval); % indices of good solutions.
itmp=itmp(msk);  % indices of updated solutions.
i=zeros(npop,1);  % empty 'score' set
i(itmp)=ii(msk);     % store rank values of good solutions
itmp=1:npop;  % want all eventually
itmp=itmp(~cval); % indices of constrained solutions.
i(itmp)=min(c(~cval,:),[],2);     % store values of constrained solutions (will be -ive)
[a,i]=sort(-i);        % get best then least constrained first

[a,r]=findang(nsamp,kk,nobj,plim);
if(~isnan(a))
    qlim=cos(a);
else
    qlim=1.1; % if too few samples due to constraint, do not clip yet
end

nkmax=1000;

% remove duplicates too:
dmax2=max(max(o)-min(o))/nkmax/2; % lower bound on neighbour distance
dmax2=dmax2^2;  % use squared distance
smsk=logical(ones(sum(cval),1));  % mask of ones to keep
for n=1:sum(cval) 
    st=smsk;
    st(n)=logical(0); % do not compare this one to self!
    dv=o(st,:)-o(n*ones(sum(st),1),:);  % difference vectors to valid.
    d2=sum(dv.^2,2); % length squared
    if(min(d2)<dmax2)
        smsk(n)=logical(0); % cut this one if too close
    end
end

itmp=1:npop;  % want all eventually
itmp=itmp(cval); % indices of good solutions.
itmp=itmp(q>qlim | ~smsk); % get those to remove from all solution set

ncrop=sum(q>qlim);

mm=c(itmp,end)<0;
c(itmp(mm),end)=-(1-0.5*(1+c(itmp(mm),end)));  % reduce chances of ones considered 'inside'
c(itmp(~mm),end)= -0.5;               % flaag as being possibly inside

% if too many being considered, set some as being possibly inside
mq=cval& c(:,end)>0;
if(sum(mq)> nkmax)
    shdist=shd(mq);
    [a,ix]=sort(-shdist);
    % choose 2 times difference between wanted no. and actual: 50:50 cut
    % chance next iteration
    a=abs(randn(1,2*(sum(mq)-nkmax))).^2;  % intervals, biased small
    b=cumsum(sort(abs(a)));
    b=ceil(b/max(b)*sum(mq));
    b=unique(b(1:end-1));  % indices of those to cut
    ix=ix(b);
    itmp=1:npop;  % want all eventually
    itmp=itmp(mq); % indices of good solutions.
    itmp=itmp(ix); % get those to remove
    c(itmp,end)=-0.5;  % if too many solutions, crop off most crowded (approx half)
end
