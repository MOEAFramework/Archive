%
% runme.m  Examples of Direct Objective Boundary Identification 
%
% E.J.Hughes 15/3/2008

%% Check that distribution of distance to nearest neighbour is actually exponential
% mean of 1/2N

N=25;
ntr=10000;

xx=zeros(ntr,N);
for n=1:ntr

    a=sort(rand(1,N));
    da=[a(2:end)-a(1:end-1) a(1)+1-a(end)];
    xx(n,:)=min(da(1),da(2));
end

tdat=reshape(xx,1,N*ntr);

[pr,ci]=expfit(tdat)

stp=0.05;
a=[0:stp:3]/N;
q=histc(tdat,a);
figure(1);
plot(a,q/ntr/stp,a,exppdf(a,1/2/N))
grid
title(['Experimental fit of NND to anticpated exponential profile (' num2str(N) ' points)'])
xlabel('distance')
ylabel('Probability density')

%% next look at behaviour on a 2 objective problem; modified TANAKA
% look at full boundary first (5000 function evaluations in total)
% pop=100, 50 generations.

 display('Press a key to perform minimisation and maximisation of 2D modified TANAKA function')
 pause
 dobi_ep(@objmocons,100,49,1,2);
 
 display('press a key to perform minimum only of 2D modified TANAKA function')
 pause
 dobi_ep(@objmocons,100,49,0,2);
 
%% alternative 2D with disconected objective regions; actual Pareto front
 %% is concave but hard to find! again only 5000 evaluations used.
 
 display('press a key to perform min& max of 2D disconected function')
 pause
 dobi_ep(@nobj1,100,49,1,2);
 
 display('press a key to perform min only of 2D disconected function')
 pause
 dobi_ep(@nobj1,100,49,0,2);
 
%% The OSY 2D test function where the decision space and objective space
 %% are very different.
 
 display('press a key to perform min& max of 2D OSY function')
 pause
 dobi_ep(@objosy,100,49,1,2);
 
 display('press a key to perform min only of 2D OSY function')
 pause
 dobi_ep(@objosy,100,49,0,2);
 
%% Many objective test - constraint boundary of hyper-sphere. 
 nobj=6;  % number of objectives to optimise
 display(['press a key to perform min& max of ' num2str(nobj) 'D hypersphere function'])
 pause
 dobi_ep(@(x) objhigh(x,nobj),100,49,1,2);
 
 display(['press a key to perform min only of ' num2str(nobj) 'D hypersphere function'])
 pause
 
 % uncomment lines if repeated runs needed to populate performance
 % comparison figures.
 %Tobj=[];
 %Tcons=[];
 %cvalx=0;
 %while(cvalx<5000)
     [obj,chrom,cons]=dobi_ep(@(x) objhigh(x,nobj),100,49,0,2);
  %   Tobj=[Tobj;obj];
  %   Tcons=[Tcons;cons];
  %   cval=sum(Tcons(:,1:end)<0,2)==0;
  %   cvalx=sum(cval);
 %end
 %[a,i]=sort(rand(1,cvalx)); % random indices
 %tt=1:size(Tobj,1);
 %tt(~cval)=[];
 %tt(i(5001:end))=[];        % get indexes of those to keep only
 %dobi_res=Tobj(tt,:);       % get random subset

  
%% process many objective results to see how well we did at
% finding Objective front
 cval=sum(cons(:,1:end)<0,2)==0;  % true if objective front
 cvali=cons(:,end)<0;     % true if considered interior
 cvalx = ~cval & ~cvali;  % true if really constrained
 figure(2)
 hist(sqrt(sum(obj(cval,:).^2,2)),50)
 grid
 title('final results distance from origin to objective front (ideally=1)')
 
 figure(3)
 hist(sqrt(sum(obj(cvali,:).^2,2)),50)
 grid
 title('distance from origin for interior (ideally>1)')

 figure(4)
 hist(sqrt(sum(obj(cvalx,:).^2,2)),50)
 grid
 title('distance from origin for constrained (ideally<1)')

%% compare to straight random search, NSGA-II and MSOPS-II
% 3D first

nobj=3;
load 3D_trial_res   % load pre-stored results to save time

% generate random points on-the-fly
crx=[];  %get 5000 valid random points
orx=[];
while(sum(crx>=0)<5000)
    [orxx,crxx]=objhigh(rand(5000,nobj),nobj);
    orx=[orx;orxx];
    crx=[crx;crxx];
end
orx=orx(crx>=0,:);
orx=orx(1:5000,:);
figure(5)
dx=sqrt(sum(dobi_res.^2,2));
rx=sqrt(sum(orx.^2,2));     % capture data values

 % tt=0:0.02:2.5;
dt=0.005;
tt=0.99:dt:1.5;

nx=sqrt(sum(nsga_res.^2,2));  % get distance of NSGA-II to Pareto front
nn=histc(nx,tt)/size(nx,1)/dt; % grab histogram data

np2=sqrt(sum(msops_res.^2,2)); % get MSOPS-II results
npx=histc(np2,tt)/size(np2,1)/dt;

 nr=histc(rx,tt)/size(rx,1)/dt;  
 nd=histc(dx,tt)/size(dx,1)/dt;    % bin quantities for pdf probabilities

 plot(tt,nr,'r^-',tt,nd,'bs-',tt,nn,'ko-',tt,npx,'g.-')
 axis([0.99 1.2 0 max([nr;nd;nn;npx])])
 legend('RAND','DOBI','NSGA-II','MSOPS-II')
 grid
 title(['PDF of distance from origin to objective front (' num2str(nobj) 'D)'])
 xlabel('distance')
 ylabel('Probability density')

 
%% compare to straight random search, NSGA-II and MSOPS-II
% 6D next
 
load 6D_trial_res   % load pre-stored results to save time
nobj=6;
% generate random points on-the-fly
crx=[];  %get 5000 valid random points
orx=[];
while(sum(crx>=0)<5000)
    [orxx,crxx]=objhigh(rand(5000,nobj),nobj);
    orx=[orx;orxx];
    crx=[crx;crxx];
end
orx=orx(crx>=0,:);
orx=orx(1:5000,:);

figure(6)
dx=sqrt(sum(dobi_res.^2,2));
rx=sqrt(sum(orx.^2,2));     % capture data values

dt=0.02;
tt=0.98:dt:2.5;

nx=sqrt(sum(nsga_res.^2,2));  % get distance of NSGA-II to Pareto front
nn=histc(nx,tt)/size(nx,1)/dt; % grab histogram data

np2=sqrt(sum(msops_res.^2,2)); % get MSOPS-II results
npx=histc(np2,tt)/size(np2,1)/dt;

 nr=histc(rx,tt)/size(rx,1)/dt;  
 nd=histc(dx,tt)/size(dx,1)/dt;    % bin quantities for pdf probabilities

 plot(tt,nr,'r^-',tt,nd,'bs-',tt,nn,'ko-',tt,npx,'g.-')
 axis([0.98 2.0 0 max([nr;nd;nn;npx])])
 legend('RAND','DOBI','NSGA-II','MSOPS-II')
 grid
 title(['PDF of distance from origin to objective front (' num2str(nobj) 'D)'])
 xlabel('distance')
 ylabel('Probability density')
  
%% Test that the conversion to ratio from angle indeed does make the
% algorithm independent of the number of objectives, and compare
% Monte-carlo results to the analytic CDF equation.
npts=1000;       % number of points on sphere

objs=2:20;       % number of objectives to study
nxx=2.^(0:10);   % size of local search
ntrx=100         % number of monte-carlo trials to average
bq=zeros(length(objs),length(nxx),ntrx);   % used to record mean

for jj=1:ntrx
    for kk=1:length(objs)
        for ff=1:length(nxx)
            nobj=objs(kk);        % number of objectives
            nxxq=nxx(ff);         % size of random search
            
            p=randn(npts+1,nobj);
            lp=sqrt(sum(p.*p,2));
            p=p./lp(:,ones(1,nobj));  % uniform distribution on hypersphere
            
            p(1,:)=zeros(1,nobj);  % centre point as reference,
            
            [npop,nvar]=size(p);
            
            tv=zeros(size(p));
            q=zeros(npop,1);
            
            dv=p-p(ones(npop,1),:);  % difference vectors
            dv(1,:)=[];  % not this one
            d=sqrt(sum(dv.^2,2)); % length
            dv=dv./d(:,ones(nvar,1)); % unit length
            
            % do nxxq point random search of hypercones
            q(1)=inf;
            for m=1:nxxq
                vv=randn(1,nvar);      % random vector "m" initially
                vv=vv/sqrt(vv*vv');    % unit length
                h=dv*vv';  % dot product with all others on hypersphere
                [qt,i]=min(-h); % find closest set
                if(-qt(1)<q(1))
                    q(1)=-qt(1);
                    tv(1,:)=vv;   % record best of random search
                end
            end
            
            % analyse now, convert angle to ratio
            rr=1./findN(acos(q(1)),nobj);

            bq(kk,ff,jj)=rr; % record data for calc of mean
        end
        [jj kk ff acosd(q(1)) rr]
    end

    %plot image of hyperspherical cap ratios; image shows pattern that is
    %independent of the number of objectives, dependent only on the size of
    %the random search.
    figure(1)
    mq=squeeze(sum(bq,3))/jj;
    imagesc(log2(nxx),objs,mq)  % plot image of ratios
    colorbar
    xlabel('Log_{10}(number of random trials)')
    ylabel('Number of objectives')
    title('Calculated ratio of hypercap area (independent of N_{obj})')
    drawnow
end


%%  mean of random search results, use to test independence of objectives
eR=zeros(6,1);
for mm=1:length(eR)
    l=npts;
    N=nxx(mm);
    for hh=0:(N-1)
        eR(mm,1)=eR(mm,1)+N/l*nchoosek(N-1,hh)*(-1)^hh/(1+hh)^2;
    end
end

figure(10)
plot(objs(1:6),(eR(:,ones(1,19))'./mq(:,1:6)-1)*100)
xlabel('Number of objectives')
ylabel('Percentage error from prediction')
title('Model accuracy: comparison of Monte-carlo results vs. prediction')
grid
%%

%
% plot empirical CDF overlaid with calculated CDF (equation (6))
al=0:0.0001:0.01;       % ratios to be evaluated 
F=zeros(length(al),50); 
l=npts;                 % number in local region (to give lambda)
for a=1:length(al)
for N=1:50;
    for hh=0:(N-1)
        F(a,N)=F(a,N)+N*nchoosek(N-1,hh)*(-1)^hh/(1+hh)*(1-exp(-l*al(a)*(hh+1)));
    end
end
end

% figure shows how the ratio limit used in the in/out test varies with the
% number of points used in the random search.  The 95% threhsold will
% provide a changing limit as appropriate.  The ratio limit will be independent
% of the number of objectives.

figure(7)
imagesc(1:50,al,F)
colorbar
grid
xlabel('N_{max}')
ylabel('test limit of ratio')

% show a comparison of the analytic CDF against the mean monte-carlo
% results (mean taken over the 19 different objective sizes and also over
% the 100 trials, each point being the mean of 1900 results).
% the curves are for 2, 4, 8, 16 and 32 points in the random search (above
% 50 points and the analytic function becomes difficult to cacluate due to
% the factorials involved)

dd=zeros(1,101);
for tx=1:5
    for n=1:101;
        dd(n)=mean(squeeze(sum(bq(:,tx,:)<al(n),3)));
    end

    figure(9)
    plot(al,dd/100,al,F(:,2^(tx-1)));
    hold on
end
grid
hold off
figure(gcf)
xlabel('Area ratio, R')
ylabel('P(X\leq R)')
title(['Comparison of mean Monte-Carlo results versus Eq.6 for 2,4,8,16 and 32 point search, N_l=' num2str(npts)])


 
 
%% add NSGA2 results

%load dobi_nsga2_080616b
% Tda=zeros(100*100,size(B{1,1},2));
% for n=1:100;
%     Tda(((n-1)*100+1):(n*100),:)=B{1,n};
% end

%%
% load 080618d

 %[a,i]=sort(rand(1,size(Tda,1))); % random indices
 %Tda=Tda(i(1:5000),:);     % get random subset
 
 
% nx=sqrt(sum(Tda.^2,2));
% nn=histc(nx,tt)/size(nx,1)/.02;
% hold on
% plot(tt,nn,'ko-')
% axis([0.95 2.5 0 max([nr;nd;nn])])
 %figure(gcf)

%% add MSOPS2 results

% load 080616c
% load 080618e
 %[a,i]=sort(rand(1,size(txq,1))); % random indices
 %txq=txq(i(1:5000),:);     % get random subset

%np2=sqrt(sum(txq.^2,2));
% npx=histc(np2,tt)/size(np2,1)/.02;
% hold on
% plot(tt,npx,'g.-')
% axis([0.9 2.0 0 max([nr;nd;nn;npx])])
