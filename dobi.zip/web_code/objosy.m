%
% objosy.m
%

function [obj,c,ub,lb]=objosy(chrom)

ub=[10 10 5 6 5 10];% upper bound on genes
lb=[0 0 1 0 1 0];% lower bound on genes

nobj=2;                 % no. of objectives
ncons=6;                % no. of constraints 

if nargout==4
  obj=nobj;
  c=ncons;
  return;
elseif nargin==1
    flaag=0;
end

[popsize,nvar]=size(chrom);  % chrom is array of chromosomes

if(nargout==2) % we want an objective value

    obj=zeros(popsize,nobj);      % allocate output space
    c=ones(popsize,ncons);         % allocate output space
    for n=1:popsize            % loop for all
        [obj(n,:),c(n,:)]=objfcn(chrom(n,:));  % calc objective
    end

end
    
% acutal objective function
function [o,c]=objfcn(chrom)

[p,n]=size(chrom);

% Test problem OSY
%    # of real variables = 6
%    # of bin variables = 0
%    # of objectives = 2
%    # of constraints = 6
%    */

x=chrom(1:5)-[2 2 1 4 1];
o(1)=-sum(x.^2.*[25 1 1 1 1]);
o(2)=sum(chrom.^2);
c(1)=chrom(1)+chrom(2)-2;
c(2)=6-chrom(1)-chrom(2);
c(3)=2-chrom(2)+chrom(1);
c(4)=2-chrom(1)+3*chrom(2);
c(5)=4-(chrom(3)-3)^2-chrom(4);
c(6)=(chrom(5)-3)^2+chrom(6)-4;
