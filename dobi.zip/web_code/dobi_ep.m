%
% Direct Objective Boundary Identification EP
%
% simple Evolutionary Programme
%
% Mutation only
%
% E.J.Hughes 14/11/2007

function [obj,chrom,cons,best_obj,best_chrom]=dobi_ep(fobj,p,maxgen,sflaag,gflaag);
%% parameters common to all EAs

fsrt=@sort_pop;     % sorting method

if(nargin<2)
    p=100;          % population size
end

if(nargin<3)
    maxgen=50;     % maximum number of generations
end

if(nargin<4)
    sflaag=0;      % 0 for minimise all objectives, 1 for min and max.
end


eqn=zeros(2,maxgen);
%% parameters for this technique

reduc=0.9;     % reduction factor for sigma 
	           % i.e. non-uniform mutation,
	           % also called forced convergence
if(nargin<5)
    gflaag=2;      % =0 for no figures at all, 1 for last only, 2 for each gen.
end
%% Main code
% get number of objectives and constraints and genes
etx=clock;  % record start time
[nobj,ncons,ub,lb]=fobj([]); 
ncons=ncons+1; % use for inside/not inside flaag
bnd=[ub;lb];   % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene

sigma_0=rng/8;                % initial standard deviation of mutations 
sigma=sigma_0;                % working standard deviation of mutations 
nvar=size(bnd,2);           % number of variables



%% initialise population and variables
  
chrom=rand(p,nvar).*(ones(p,1)*rng)+ones(p,1)*bnd(2,:);
                            % initial pop. lb<= x <=ub
gen=0;                      % generation counter

[obj,cons]=fobj(chrom);     % evaluate initial pop.
cons=[cons ones(p,1)];      % add flaag to say all appear inside

shd=NaN*zeros(p,1);         % share distances

%% Main loop
rru=ones(p,1)*bnd(1,:);             % matrix of upper limits
rrl=ones(p,1)*bnd(2,:);             % matrix of lower limits

while(gen<maxgen)
  
  chx=chrom(1:p,:)+randn(p,nvar).*(ones(p,1)*sigma); % create new chromosomes
                                         % adds Gaussian noise for
                                         % a mutation with standard
                                         % deviation of `sigma',
  msk=chx>rru;                 % find those over-range
  chx(msk)=chrom(msk)+(rru(msk)-chrom(msk)).*rand(sum(sum(msk)),1);  % move into interval with parent
  %chx(msk)=rr(msk);            % basic crop to upper range
  msk=chx<rrl;                 % find those under-range                                        
  chx(msk)=chrom(msk)+(rrl(msk)-chrom(msk)).*rand(sum(sum(msk)),1);  % move into interval with parent
%  chx(msk)=rr(msk);            % basic crop to lower range

  [objx,consx]=fobj(chx);     % re-evaluate old chroms, and first time for new 
  shdx=NaN*zeros(p,1);               % share distances

  
  consx=[consx ones(p,1)];      % add flaag to say all appear inside

  objx=[obj;objx];                       % form joint population with old and new
  consx=[cons;consx];                    % form joint population with old and new
  chx=[chrom;chx];                       % concatenate old & new chroms
  shdx=[shd;shdx];                       % concatenate old & new share distances


  [i,consx,shdx]=fsrt(objx,consx,shdx,sflaag);  % sort to find best, and censor 'inside'

  
%  obj=objx(i(1:p),:);                    % take best `p' objectives
%  cons=consx(i(1:p),:);                  % take best `p' constraints
%  chrom=chx(i(1:p),:);                   % take best `p' chromosomes

  obj=objx(i,:);                    % take best `p' objectives
  cons=consx(i,:);                  % take best `p' constraints
  chrom=chx(i,:);                   % take best `p' chromosomes
  shd=shdx(i,:);                    % take best `p' chromosomes

  gen=gen+1;                             % increment counter
  sigma=sigma*reduc;                     % reduce `sigma' for mutation
  
  % plot convergence graph
  if( (gflaag && gen==maxgen) || gflaag>1)
     
      figure(11)
      cval=sum(cons(:,1:end)<0,2)==0;  % true if valid
      cvali=cons(:,end)<0;     % true if interior
      plot(obj(~cval,1),obj(~cval,2),'y.',obj(cvali,1),obj(cvali,2),'g.',obj(cval,1),obj(cval,2),'k.') % plot objectives
      xlabel('obj1')
      ylabel('obj2')
      title(['Generations: ' num2str(gen)])
      grid
      drawnow

  end
end % end of main loop

elapsed_time=etime(clock,etx)
best_chrom=chrom(cval,:);
best_obj=obj(cval,:);  % output final best results
   

