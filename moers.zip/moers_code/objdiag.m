% objdiag.m  Objective function 
% 
% constraint =1 is ok, 0 does not work.
%
% E.J.Hughes 24/3/06


function [obj,c,ub,lb]=objdiag(Chrom,flaag,v)

nobj=2;                           % 2 objectives
ncons=1;                          % 1 constraint 

ub=[1 1];  % upper bound on genes (2 gene problem)
lb=[0 0];  % lower bound on genes

if nargin==0
  obj=nobj;
  c=ncons;
  return;
end

if nargin<3
    v=5;   % controls density of Pareto set
end

[popsize,nvar]=size(Chrom);


% Loop for all chromosomes 

obj=zeros(popsize,nobj);
c  = ones(popsize,1);      % all unconstrained to start

for hjj=1:popsize

  chrom=Chrom(hjj,:);

  x=chrom(1).^(1/v);
  y=chrom(2).^(1/v);
  
  %% Calculate objectives

  o1=x;
  o2=y;

  obj(hjj,:)=[o1 o2];
    
  c(hjj,:)  = o1+o2 >= 1;   % constraint
  
end

