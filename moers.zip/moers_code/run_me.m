%
% run_me.m
%
% Top-level file for MOERS demonstration
%
% E.J.Hughes 26/3/2006

% first recall the NSGA-II data to show MOERS performance
% on the example ``diagonal'' test function.

clear all

disp('Obtaining data for NSGA-II')
% Example results from the NSGA-II optimiser are loaded in.  If you 
% wish to create alternative instances of the results, uncomment the next
% line.  You will need to follow the instructions in nsga2driver.m though
% to make sure you have the nsga2 executable compiled for the correct
% objective!

%nsga2driver
load nsga2_diag_full_5

% analyse the results now:
disp('analysing NSGA-II results')

% the following uses the analytic definition of the `diagonal' test
% function.  To use the monte-carlo method, swap the commenting on the
% following two lines.  The monte-carlo method is slower and some
% 'clipping' of the results may occur if insufficient monte-carlo samples
% are generated.

moers_analytic
%moers_mc

disp('Press a key to analyse a random search')
pause

disp('Obtaining data for NSGA-II')
% Example results from the random search optimiser are to be loaded in.  If you 
% wish to create alternative instances of the results, uncomment the next
% line.

%randdriver
load rand_diag_full_5

% analyse the results now:
disp('analysing random search results')

% the following uses the analytic definition of the `diagonal' test
% function.  To use the monte-carlo method, swap the commenting on the
% following two lines.  The monte-carlo method is slower and some
% 'clipping' of the results may occur if insufficient monte-carlo samples
% are generated.

moers_analytic
%moers_mc
