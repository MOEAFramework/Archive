%
% Multi-objective Equivalent Random Search
%
% calculates equivalent performance using analytic CDF
%
% E.J.Hughes 16/3/2006

% needs Pareto sets in cell array B on entry to the script and pnx, gnx 
% holding the population sizes and number of generations used.
%
% see randdriver.m for demonstration of how the three variables are
% created.

v=5;   % shape of Pareto set
% create weight vectors spread across Pareto surface 
ang=(eps:(90-2*eps)/199:90-eps)'/180*pi;
tv=[cos(ang) sin(ang)];
mval=1:length(ang);

dtaN=zeros(size(B,1),2,5);  % storage for results matrix
dtaLSR=zeros(size(B,1),2,5);  % storage for results matrix

for kk=1:size(B,1);
    
    nref=pnx(kk)*gnx(kk);  % number actually used
    prbs=zeros(size(B,2),length(mval));  % space for CDF results
    for n=1:length(mval)
        n
        w=max(tv(n,:))/min(tv(n,:));  % weighted min-max vectors
        for f=1:size(B,2)
            %test all the Pareto sets against CDF
            t=B{kk,f}.*tv(mval(n)*ones(size(B{kk,f},1),1),:);   % find projection onto target vector
            m=max(t,[],2)/min(tv(n,:));     % weighted min-max
            q=min(m);                       % best performance on this vector
            if(~isempty(q))
                % calc D(q) analytically
                if(q<1)
                    d=q.^(2*v)/w^v-q.^v.*(1-q).^v;
                    for r=0:v
                        d=d+(-1)^r*v/(v+r)*prod(1:v)/prod(1:r)/prod(1:(v-r))*((1-q).^(v+r)-(q/w).^(v+r));
                    end
                else
                    d=q.^v/w^v;
                    for r=0:v
                        d=d-(-1)^r*v/(v+r)*prod(1:v)/prod(1:r)/prod(1:(v-r))*(q/w).^(v+r);
                    end
                end
                prbs(f,n)=d;  % probability of being able to improve result.
            else
                prbs(f,n)=1;  % if no set present, really bad.
            end
        end
    end

    % plot MOERS results for each Pareto set...
    Nmed=log10(log(0.5)./log(1-median(prbs)));  % vector of median results
    figure(43)
    rr=log10(log(0.5)./log(1-sort(prbs,1)));  % vector to assess median performance;
    tn=size(B,2);  % number of samples
    dt=1.96*sqrt(tn)/2;  % number of cells from median for 95% confidence
    plot(1:length(mval),sort(rr(floor((tn+1)/2-dt),:)),'k--', ...
        1:length(mval),sort(Nmed),'k', ...
        1:length(mval),sort(rr(ceil((tn+1)/2+dt),:)),'k--')
    grid
        
    Nwrstu=log10(log(1-(1-0.025)^(1/tn))./log(1-max(prbs)));  % 95% conf limit
    Nwrst=log10(log(1-(1-.5)^(1/tn))./log(1-max(prbs)));      % worst performance
    Nwrstl=log10(log(1-(1-0.975)^(1/tn))./log(1-max(prbs)));  % 95% conf limit
    hold on
    plot(1:length(mval),sort(Nwrstu),'r--', ...
        1:length(mval),sort(Nwrst),'r', ...
        1:length(mval),sort(Nwrstl),'r--')
    plot([1 length(mval)],[log10(nref) log10(nref)],'g')      %plot actual number of evals
    hold off
    
    xlabel('Target vector number')
    ylabel('Equivalent Random Search 10^x')
    title('Multi-Objective Equivalent Random Search')
    set(gcf,'PaperUnits','centimeters','PaperPosition',[1 1 12 10]);
    qw=sort(Nwrst);
    qm=sort(Nmed);
    rl=floor(0.025*length(mval));
    ru=ceil(0.975*length(mval));
    
    disp(['Nwrst [' num2str(10.^[qw(rl) median(Nwrstl) median(Nwrst) median(Nwrstu) qw(ru)]) ']']);
    disp(['Nmed  [' num2str(10.^[qm(rl) median(rr(ceil((tn+1)/2+dt),:)) median(Nmed) median(rr(floor((tn+1)/2-dt),:)) qm(ru)]) ']']);

    % record results for final graphs
    dtaN(kk,1,:)=[qw(rl) median(Nwrstl) median(Nwrst) median(Nwrstu) qw(ru)];
    dtaN(kk,2,:)=[qm(rl) median(rr(ceil((tn+1)/2+dt),:)) median(Nmed) median(rr(floor((tn+1)/2-dt),:)) qm(ru)];

    dtaLSR(kk,:,:)=dtaN(kk,:,:)-log10(nref);   % store results
    
    disp(['Log(Nwrst) [' num2str([qw(rl) median(Nwrstl) median(Nwrst) median(Nwrstu) qw(ru)]) ']']);
    disp(['Log(Nmed)  [' num2str([qm(rl) median(rr(ceil((tn+1)/2+dt),:)) median(Nmed) median(rr(floor((tn+1)/2-dt),:)) qm(ru)]) ']']);
    
    disp(['LSRwrst [' num2str([qw(rl) median(Nwrstl) median(Nwrst) median(Nwrstu) qw(ru)]-log10(nref)) ']']);
    disp(['LSRmed  [' num2str([qm(rl) median(rr(ceil((tn+1)/2+dt),:)) median(Nmed) median(rr(floor((tn+1)/2-dt),:)) qm(ru)]-log10(nref)) ']']);
    
    drawnow
end

% draw graphs of how metrics changed as the number of evals increased
figure(123)
plot(log10(gnx.*pnx),dtaLSR(:,1,3),log10(gnx.*pnx),dtaLSR(:,1,1),'r--',log10(gnx.*pnx),dtaLSR(:,1,5),'r--')
hold on
plot(log10(gnx.*pnx),dtaLSR(:,1,3),log10(gnx.*pnx),dtaLSR(:,1,2),'k--',log10(gnx.*pnx),dtaLSR(:,1,4),'k--')
hold off
grid
xlabel('Log_{10}(number of evals)')
ylabel('Log Search Ratio')
title('Worst-case results for diagonal test function, v=5')

figure(124)
plot(log10(gnx.*pnx),dtaLSR(:,2,3),log10(gnx.*pnx),dtaLSR(:,2,1),'r--',log10(gnx.*pnx),dtaLSR(:,2,5),'r--')
hold on
plot(log10(gnx.*pnx),dtaLSR(:,2,3),log10(gnx.*pnx),dtaLSR(:,2,2),'k--',log10(gnx.*pnx),dtaLSR(:,2,4),'k--')
hold off
grid
xlabel('Log_{10}(number of evals)')
ylabel('Log Search Ratio')
title('Median results for diagonal test function, v=5')
