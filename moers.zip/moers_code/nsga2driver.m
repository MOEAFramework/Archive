%
% nsga2driver.m
%
% Drives nsga2 code
%
% E.J.Hughes 16/3/2006

% first obtain the NSGA-II source code from:
% http://www.iitk.ac.in/kangal/codes/nsga2/nsga2-v1.1.tar
% and place this file in the main source-code directory.
% use the problemdef.c file supplied with this distribution, 
% renaming the original problemdef.c to problemdef.c_old so it will not get compiled in, 
% then compile NSGA-II from within Matlab using (syntax using free Borland C compiler from:
% http://www.borland.com/downloads/download_cbuilder.html )
%
%!bcc32 -ensga2r.exe *.c
%
% then run this file under matlab to generate new NSGA-II data

pnx=[40 56 80 120 168 240  344 488 704 1000]; % population sizes to use: 
                                              % NSGA needs multiple of 4.
gnx=[20 28 40  60  84 120  172 244 352 500];  % number of generations to use

B=cell(length(gnx),100);  % storage for the 1000 Pareto sets that will be created

for k=1:length(gnx) % loop over all experiments
    gen=gnx(k);
    pop=pnx(k);     % get population an no. of gens to use
    for n=1:100
        [pop gen n]
        fid=fopen('diag.in','w');  % create input file for NSGA-II
        fprintf(fid,'%d\n%d\n2\n1\n2\n0 1\n0 1\n0.9\n0.5\n5\n5\n0\n',pop,gen);
        fclose(fid);
        eval(['!nsga2r ' num2str(rand) ' < diag.in']);  % execute NSGA-II
        load best_pop.out                               % fetch Pareto set
        B{k,n}=best_pop(:,[1 2]);                       % record objective data

        save nsga2_diag_full_5 B gnx pnx                % save off each trial
    end
end

% plot some example Pareto sets - need to press a key to see each set.

for n=1:100;
    n
    figure(1)
    plot(B{5,n}(:,1),B{5,n}(:,2),'.'); 
    grid;
    axis([0 1 0 1]);
    drawnow;
    pause;
end

