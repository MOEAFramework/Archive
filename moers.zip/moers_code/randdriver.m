%
% randdriver.m
%
% Performs random search.
%
% E.J.Hughes 16/3/2006


pnx=[40 56 80 120 168 240  344 488 704 1000]; 
gnx=[20 28 40  60  84 120  172 244 352 500];
v_true=5;  % controls density of Pareto surface

nobj=2;

B=cell(length(gnx),100);

for k=1:length(gnx)
    gen=gnx(k);
    pop=pnx(k);
    
    for n=1:100
        [gen*pop n]
        ar=rand(pnx(k)*gnx(k),2);  % random search
        [ob,c]=objdiag(ar,0,v_true);
        ob(c==0,:)=[];             % remove any that are constrained
        
        if(~isempty(ob))
            % need to find Pareto set of the random points 
            dk=1./(ob+eps);         % invert for weighted min-max
            R=sqrt(sum(dk.^2,2));   % target vector lengths
            tv=dk./R(:,ones(1,nobj)); % unit vectors
            R=max(tv.*ob,[],2);       % get metric for each vector
            mval=1;                   % take first point as our reference
            %test to see if on Pareto surface...
            for nn=2:size(ob,1)
                %calculate weighted min-max metric
                t=ob(mval,:).*tv(nn*ones(length(mval),1),:); % find projection onto target vector
                m=max(t,[],2);     % weighted min-max
                if(min(m)>=R(nn))  % all beaten on new test vector, therefore lies on front
                    % need to see if we need to remove any - they are beaten by new point on their own vector
                    t=tv(mval,:).*ob(nn*ones(length(mval),1),:);  % distances along vectors
                    m=max(t,[],2);     % weighted min-max
                    idx=m<=R(mval);    % get any that are beaten
                    mval(idx)=[];      % cut if beaten
                    mval=[mval;nn];    % store results for point on objective front
                end
            end

            B{k,n}=ob(mval,:);  % record pareto set
            
            save rand_diag_full_5 B gnx pnx %save off results
        end
    end
end

% plot some example Pareto sets - need to press a key to see each set.

for n=1:100;
    n
    figure(1)
    plot(B{5,n}(:,1),B{5,n}(:,2),'.'); 
    grid;
    axis([0 1 0 1]);
    drawnow;
    pause;
end

