/* Test problem definitions */

# include <stdio.h>
# include <stdlib.h>
# include <math.h>

# include "global.h"
# include "rand.h"

# define diag

/*  Test problem diag
    # of real variables = 2
    # of bin variables = 0
    # of objectives = 2
    # of constraints = 1
    */
    
#ifdef diag
void test_problem (double *xreal, double *xbin, int **gene, double *obj, double *constr)
{
    double v=5;   /* defines denstity at Pareto surface */
    obj[0] = pow(xreal[0],1/v);
    obj[1] = pow(xreal[1],1/v);
    constr[0] = obj[0] + obj[1] -1;
    return;
}
#endif
