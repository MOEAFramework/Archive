%  Many-Objective directed evolutionary line search
%
% output mto, mtx and mtc are objective, chromosome 
% and constraint matrix of archive,
% pobj, pchrom and pcons are Pareto objective, chromosome 
% and constraint matrices.
%
% fobj is a function handle to the objective function
% p is the population size of the intial random search
% nevalmax is the total number of function evaluations to perform
% refpt (optional) is the lower reference point of the 
%   target vector set and scaling (default is origin and unity scale)
% tv is the matrix of target vectors (optional)
% aggname is a cell array of function handles for the 
%   aggregators (optional, WMM + VADS default)
% nls is a vector of up to 5 values:
%  [num_pts_on_line_search num_grad_evals grad_search_delta prob_neighbour neighbour_factor]
%    nls default=[5 0 0.0035 0.2 4];
%
% linefcn is a function handle to the method to use for line search
% default is single sided golden section.
%
% gflaag=0 for no figures (default), =1 for figs at end 
%   =2 for running figures =-2 for movies of running figures.
%
%  E.J.Hughes 27/1/2011

function [mto,mtx,mtc,pobj,pchrom,pcons]=modelsf(fobj,p,nevalmax,refpt,tv,aggname,nls,linefcn,gflaag);

rand('state',sum(100*clock));  % make sure stands a chance of being random
randn('state',sum(100*clock));

if(~exist('gflaag','var') || isempty(gflaag))
    gflaag=0;  % flaag for figure generation
end

% controls search line lenght and selection of parent
shapefac=2; % 2 will start triangular, 1 unifom , in range [0,1] is exponential.
rand_flaag=1;  % 1 for random choice of tv, 0= sequential

ndelt=0;        % number of delta points for gradient
dfac=0.0035;    % size to use to take local gradient points
Psteer=0.2;     % probability of choosing V direction based on population.
kV=4;           % number of vectors to choose from for choice of V. higher 
                % is not so targeted but is less susceptible to multiple
                % optima.

if(~exist('nls','var') || isempty(nls))
    nls=5;  % default number of points in double line search
else
    switch(length(nls))
        case 0
            nls=5;  % default number of points in double line search
        case 2
            ndelt=nls(2);  % number of delta points
            nls=nls(1);  % default number of points in double line search
        case 3
            dfac=nls(3);
            ndelt=nls(2);  % number of delta points
            nls=nls(1);  % default number of points in double line search
        case 4
            Psteer=nls(4);
            dfac=nls(3);
            ndelt=nls(2);  % number of delta points
            nls=nls(1);  % default number of points in double line search
        case 5
            kV=nls(5);
            Psteer=nls(4);
            dfac=nls(3);
            ndelt=nls(2);  % number of delta points
            nls=nls(1);  % default number of points in double line search
    end
end

if(~exist('refpt','var'))
    refpt=[];
end

if(~exist('aggname','var') || isempty(aggname))
    aggname={'wmm_agg','@(x,t) vads_agg(x,t,100)'};  % aggregation methods
end

if(~exist('linefcn','var') || isempty(linefcn))
    linefcn=@mosgoldsrch;   %line search function; many obj single sided gold section.
end

[nobj,ncons,ub,lb]=fobj([]);  % get problem size
nvar=length(ub);
bnd=[ub;lb];   % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene

if(isempty(refpt))
    refpt=[zeros(1,nobj);ones(1,nobj)];  % default reference point at origin
end

if(~exist('tv','var') || isempty(tv))
    tv=vspace(p,nobj,0);    % generate target vectors for search
end

ntv=size(tv,1);

% create cell array of target vectors and function handles.
aggfcn=cell(ntv*length(aggname),2);  % cell array for target vectors and function names
for n=1:size(aggfcn,1)
   aggfcn{n,1}=tv(mod(n-1,ntv)+1,:); % copy target vector
   aggfcn{n,2}=str2func(aggname{ceil(n/ntv)}); % copy target vector
end

nit=round((nevalmax-p)/(nls+ndelt));
neval=p+(nit.*(ndelt+nls));   % adjust number of evaluations to fit other definitions

allevalo=zeros(neval,nobj);
allevalx=zeros(neval,nvar);
allevalc=zeros(neval,ncons);   % storage for all evals.

xtz=rand(p,nvar).*(ones(p,1)*(ub-lb))+ones(p,1)*lb;  % start points
[fxt,cxt]=fobj(xtz);  %evaluate chromosome.

if(abs(gflaag)>1)
    figure(6)
    plot(xtz(min(cxt,[],2)>0,1),xtz(min(cxt,[],2)>0,2),'b.', ...
            xtz(min(cxt,[],2)<=0,1),xtz(min(cxt,[],2)<=0,2),'g.')
    %     plotmatrix(drn)
    hold on
    axis([lb(1) ub(1) lb(2) ub(2)])
    xlabel('X_1')
    ylabel('X_2')
    title('Search so far in Decision Space')
    %pause
end


if(gflaag<-1)
    figure(6)
    set(6,'DoubleBuffer','on');
    set(gca,'NextPlot','replace','Visible','on')
    mov1 = avifile(['mov1.avi']);
    mov1.Fps=20;
    mov1.Compression='cinepak';
end


allevalo(1:p,:)=fxt;
allevalx(1:p,:)=xtz;
allevalc(1:p,:)=cxt;  % record
cnty=p+1;             % position to store data in
% need to evaluate population on each target now, record best at each tv.

mt=zeros(p,1);  % store for metric values
mto=zeros(p,nobj);  % store for obj values
mtx=zeros(p,nvar);  % store for chrom values
mtc=zeros(p,ncons);  % store for constraint values
nsol=p;         % number of objective values being checked.

% calculate which are constrained first...
cw=rand(1,ncons)+0.01;
cw=cw./max(cw);   % generate a random weighting vector for constraints.
cw=cw(ones(size(cxt,1),1),:);
c=min(cxt.*cw,[],2);  %all constraints must be >0 to be good, need to maximise this value if <=0

for ff=1:size(aggfcn,1)
    jj=refpt(ones(size(fxt,1),1),:);
    hh=refpt(2*ones(size(fxt,1),1),:);
    m=aggfcn{ff,2}((fxt-jj)./hh,aggfcn{ff,1}(ones(nsol,1),:));  % evaluate objectives against target
    % need to make sure constrained are handled ok...
    if(sum(c>0))
        m(c<=0)=m(c<=0)+max(m(c>0))+eps;  % make all constrained look worse than not.
    end
    [a,i]=min(m);    % find best for this vector
    mt(ff)=a;        % metric value
    mto(ff,:)=fxt(i,:); % corresponding objective vector
    mtx(ff,:)=xtz(i,:);  % corresponding chrom vector
    mtc(ff,:)=cxt(i,:); % corresponding constraint vector
end

nipcnt=0;  % count number where no improvement made

ii=0;      % do random or loop through all
for n=1:nit
    
    if(rand_flaag)
        ii=randi(size(aggfcn,1)); % choose parent at random
    else
        ii=ii+1;
        ii=mod(ii-1,size(aggfcn,1))+1;  % loop through all
    end
    drn=zeros(ndelt+nls+1,nvar);   %storage for all vectors in this iteration
    fdrn=zeros(ndelt+nls+1,nobj);     % storage for fitness values
    cdrn=zeros(ndelt+nls+1,ncons);     % storage for fitness values
    drn(1,:)=mtx(ii,:);
    fdrn(1,:)=mto(ii,:);  % capture existing point
    cdrn(1,:)=mtc(ii,:);  % capture existing point
 
    cntx=2;       % index for next data points
    lx=ones(1,nvar);      % scope for biasing search direction
    if(Psteer>rand) % steer V based on population distribution
        
        dV=mtx(randi(size(aggfcn,1),kV,1),:)-mtx(randi(size(aggfcn,1),kV,1),:);
        lV=sum(dV.^2,2);  % length squared
        lV(lV==0)=inf;    % remove any 'zeros'

        [tmp,iV]=min(lV);
        V=dV(iV,:);  % take shortest
        
    else
        % use local gradient.
        if(ndelt==0)
            V=randn(1,nvar).*lx;  % random direction of search
        else
            delta=randn(ndelt,nvar)*dfac;% offset to calc gradients
            trxt=mtx(ii*ones(ndelt,1),:)+delta;  % new point to try
            
            % do have to be careful to make sure gradient calcs
            % adhere to implicit boundary constraints
            
            % parent-centric cropping if necessary as used in MSOPS2.  
            % good with low density at edges of search region.
            % DO NOT use simple edge cropping as it is very poor!!
          
            bse=mtx(ii,:); %parent
            for ki=1:ndelt
                rr=rand(1,nvar);bseu=bnd(1,:).*rr+bse.*(1-rr);    % somewhere between parent and bound
                rr=rand(1,nvar);bsel=bnd(2,:).*rr+bse.*(1-rr);    % somewhere between parent and bound
                trxt(ki,trxt(ki,:)>bnd(1,:))=bseu(trxt(ki,:)>bnd(1,:));       % crop to parentish for upper
                trxt(ki,trxt(ki,:)<bnd(2,:))=bsel(trxt(ki,:)<bnd(2,:));       % crop to parentish for lower
            end
            
            [fd,fc]=fobj(trxt);  % evaluate delta's
            fd=[mto(ii,:);fd];   % concatenate with current point to make life easy
            jj=refpt(ones(size(fd,1),1),:);
            hh=refpt(2*ones(size(fd,1),1),:);
            m=aggfcn{ii,2}((fd-jj)./hh,aggfcn{ii,1}(ones(size(fd,1),1),:));  % evaluate objectives against target
            % generate fitness based on aggregation function
            
            err=m(2:end)-m(1);  % errors, +ive means got worse.
            [a,i]=max(abs(err)); % find biggest step in either direction
            V=delta(i,:);        % use it as vector
            if(err(i)>0)
                V=-V;  % reverse if step was uphill
            end
            
            drn(cntx : cntx+ndelt-1,:)= trxt;
            fdrn(cntx : cntx+ndelt-1,:)= fd(2:end,:);   % store the evals
            cdrn(cntx : cntx+ndelt-1,:)= fc;   % store the evals
            cntx=cntx+ndelt;     % move pointer
                 
            allevalx(cnty : cnty+ndelt-1,:)=trxt;
            allevalo(cnty : cnty+ndelt-1,:)=fd(2:end,:);
            allevalc(cnty : cnty+ndelt-1,:)=fc;  % record
            cnty=cnty+ndelt;     % move pointer

        end
    end
    V=V/sqrt(sum(V.^2)); % make V unit length.
    % sort out length of gradient
    % find scale factor to get limit now, V needs to be considered both
    % ways.
    alux=(ub-mtx(ii,:))./V;   % alpha for upper bounds
    allx=(lb-mtx(ii,:))./V;   % alpha for lower bounds
    a=[allx alux];      % get all
    b=a;
    a(a<=0)=inf;        % remove backwards ones
    b(b>=0)=-inf;       % remove forwards ones
    alphaH=min(a);     % get first hit.
    alphaL=max(b);     % get first hit.
    
    mref=shapefac*(1-(n-1)/nit);  % % beta distributed: reverse triangle,
    %then uniform half way throught, then
    %long-tailed in unit interval.
    mdx=[gamrnd(mref,1) gamrnd(1,1)];
    mdx=mdx(:,1)./sum(mdx,2);     
   
    % have direction and limits now.  can do search.
    % nls needs to include end of line as extra point to eval.
    jj=refpt(1,:);
    hh=refpt(2,:);
    [x,f,ox,cx,ccx,ix]=linefcn(@(x) fobj(mtx(ii,:)+x*V), ...
        mto(ii,:),nls,alphaL*mdx,alphaH*mdx, ...
        nvar,@(x,t) aggfcn{ii,2}((x-jj)./hh,t),aggfcn{ii,1},mtc(ii,:));  % line search, scale with iteration
        
    % if best f is the first, it means point was not moved; may be able
    % to use this info to improve search direction next time?
    
    % count if not moved...
    if(min(x)==0)
        nipcnt=nipcnt+1;
    end
    % record points taken
    drn(cntx : cntx+nls-1,:)= mtx(ones(nls,1)*ii,:)+cx*V;
    fdrn(cntx : cntx+nls-1,:)= ox;   % store the evals
    cdrn(cntx : cntx+nls-1,:)= ccx;   % store the evals
   % cntx=cntx+nls;     % move pointer

%   allevalo(p+(n-1)*nls+1:p+n*nls,:)=ox;
%   allevalx(p+(n-1)*nls+1:p+n*nls,:)=drn(cntx : cntx+nls-1,:);
%   allevalc(p+(n-1)*nls+1:p+n*nls,:)=ccx;  % record
   allevalo(cnty : cnty+nls-1,:)=ox;
   allevalx(cnty : cnty+nls-1,:)=drn(cntx : cntx+nls-1,:);
   allevalc(cnty : cnty+nls-1,:)=ccx;  % record
   cnty=cnty+nls;     % move pointer
    
    if(abs(gflaag)>1)
        figure(6)
        plot(drn(min(cdrn,[],2)>0,1),drn(min(cdrn,[],2)>0,2),'b.', ...
            mtx(:,1),mtx(:,2),'r*', ...
            drn(min(cdrn,[],2)<=0,1),drn(min(cdrn,[],2)<=0,2),'g.')
   %     plotmatrix(drn)
        hold on
        axis([lb(1) ub(1) lb(2) ub(2)])
        xlabel('X_1')
        ylabel('X_2')
        title('Search so far in Decision Space')
        %pause
    end
    if(abs(gflaag)>1)
        figure(5)
        plot(fdrn(min(cdrn,[],2)>0,1),fdrn(min(cdrn,[],2)>0,2),'b.', ...
            mto(:,1),mto(:,2),'r*', ...
            fdrn(min(cdrn,[],2)<=0,1),fdrn(min(cdrn,[],2)<=0,2),'g.')
        % hold on
        xlabel('Obj_1')
        ylabel('Obj_2')
        title('Archive in Objective Space')
      %  axis([lb(1) ub(1) lb(2) ub(2)])
    end
    drawnow
    
    if(gflaag < -1)
        Frm = getframe(6);
        mov1 = addframe(mov1,Frm);
    end

    
    % update target vector archive based on all new calculations.
    % calculate which are constrained first...
    cw=rand(1,ncons)+0.01;
    cw=cw./max(cw);   % generate a random weighting vector for constraints.
    cw=cw(ones(size(cdrn,1),1),:);
    c=min(cdrn.*cw,[],2);  %all constraints must be >0 to be good, need to maximise this value if <=0

    jj=refpt(ones(size(fdrn,1),1),:);
    hh=refpt(2*ones(size(fdrn,1),1),:);

    for ff=1:size(aggfcn,1)  % loop over all target vectors

        m=aggfcn{ff,2}((fdrn-jj)./hh,aggfcn{ff,1}(ones(ndelt+nls+1,1),:));  % evaluate objectives against target
%        m=aggfcn(fdrn,tv(ff*ones(nls+1,1),:));  % evaluate objectives against target
        % need to make sure constrained are handled ok...
        if(sum(c>0))
            m(c<=0)=m(c<=0)+max(m(c>0))+eps;  % make all constrained look worse than not.
        end
        [a,i]=min(m);    % find best for this vector
        
        % see if better than what is stored...
        
        ind=double(c(i)>0) + double(min(mtc(ff,:))>0);  % 0 if both cons, 1 if only one 2 if ok.
        flaag=0;  % indicate take no update as default
        switch(ind)
            case 0
                % both constrained, largest min wins
                if(min(mtc(ff,:))<c(i))
                    flaag=1;
                end
            case 1
                % one is constrained
                if(c(i)>0)
                    flaag=1;
                end
                
            case 2
                % both ok. take best side (lowest):
                % need to aggregate
                if(mt(ff)>a)
                    flaag=1;
                end
        end
        
        if(flaag)  % need to replace old point
            mt(ff)=a;        % metric value
            mto(ff,:)=fdrn(i,:); % corresponding objective vector
            mtx(ff,:)=drn(i,:);  % corresponding chrom vector
            mtc(ff,:)=cdrn(i,:); % corresponding constraint vector
        end
    end
      
end
    
if(abs(gflaag)>1)
    figure(5)
    hold off
    grid
    figure(6)
    hold off
    grid
end

if(gflaag < -1)
    mov1 = close(mov1);
end

% if we do direction selection to other solution, may not do all grad
% searches.
allevalo=allevalo(1:cnty-1,:);
allevalc=allevalc(1:cnty-1,:);
allevalx=allevalx(1:cnty-1,:);

c=min(allevalc,[],2);  %all constraints must be >0 to be good, need to maximise this value if <=0
r=parset(allevalo(c>0,:));   % only do valid obj
z=1:size(allevalo,1);
z=z(c>0);  % mask out constrained
z=z(r);  % get pareto

if(abs(gflaag)>0)
    figure(42)
    plot(allevalo(z,1),allevalo(z,2),'.')
    grid
end
pobj=allevalo(z,:);
pchrom=allevalx(z,:);
pcons=allevalc(z,:);
cnty

