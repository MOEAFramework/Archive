%
% objhigh.m
%
% Objective function that is for high-dimensional test.
% E.J.Hughes 6/3/2007

function [obj,c,ub,lb]=objhigh(chrom,nobj)

if(nargin<2)
    nobj=3;    % set default to a 3D
end

% These lines define the upper/lower bounds on decision space.
% This function allows range (0,1] to be used by optimiser for simplicity
ub=ones(1,nobj);% upper bound on genes
lb=zeros(1,nobj);% lower bound on genes

ncons=1;                % no. of constraints, put a dummy constraint in. 

% if function is called as [o,c,ub,lb]=objpri()
% returns:
% o = number of objectives
% c = number of constraints
% ub = vector of upper decision variable bounds
% lb = vector of lower decision variable bounds
if nargout==4
  obj=nobj;
  c=ncons;
  return;
end

[popsize,nvar]=size(chrom);  % chrom is array of chromosomes

obj=zeros(popsize,nobj);      % allocate output space for objectives
c=ones(popsize,ncons);        % allocate output space for constraints
for n=1:popsize               % loop for all
    [obj(n,:),c(n,:)]=objfcn(chrom(n,:));  % calculate objective
end

    
% acutal objective function
function [o,c]=objfcn(chrom)

o=chrom;
c=sqrt(sum(chrom.^2))-1; % constraint ok if >=0, invalid otherwise.
                    