%
% morandsrch.m   does many objective single sided random point line search
%
% MO and random mods 28/1/2011
% infx is the capture of the chromosome information
%
% designed to tolerate crappy functions.

function [x,f, objx, chromx, consx infx]=morandsrch(fobj, fx1, N, lb,ub,nvar,aggfcn,tv,cc1)
% fx1 is fitness of initial trial point that lies on search line
% N is number of function evals to do
% ub and lb are the scale factors for left/right on x vector, lb not used.

nobj=length(tv);  % number of objectives
ncons=length(cc1); % number of constraints
cw=rand(1,ncons)+0.01;
cw=cw./max(cw);   % generate a random weighting vector for constraints.
 
mz=zeros(N+1,3);    % location, metric vector and flaag for constrained, allow intial point.  
objx=zeros(N,nobj);
consx=zeros(N,ncons);
chromx=zeros(N,1); % storage for my evals
infx=zeros(N,nvar); % storage for my chrom info

%do far side first (lb):
cnt=1; % count number of function evals
x1=0;  % one point in centre

%store initial point
mz(1,:)=[0 aggfcn(fx1,tv) min(cc1.*cw)];  % evaluate aggregation


% eval and store end point
[fxl,ccl,ii]=fobj(ub);    % also need to store all other evals too for EA use             
objx(cnt,:)=fxl;
chromx(cnt,:)=ub; % store eval
consx(cnt,:)=ccl; % store eval
infx(cnt,:)=ii; % store eval
mz(cnt+1,:)=[ub aggfcn(fxl,tv) min(ccl.*cw)];  % evaluate aggregation
cnt=cnt+1;

% find bounds first....
% need to track the 'interior points', so generate the pair...

% do search: discard highest outside point and generate new interior
while(cnt<=N)

    mh=mz(1:cnt,2);  % all aggregations
    c=mz(1:cnt,3);  % all constraint values 
    if(sum(c>0))
        mh(c<=0)=mh(c<=0)+max(mh(c>0))+eps;   % make constrained worst
    end
    [a,i]=sort(mh);  % get lowest values
    
    r=0.05+0.9*rand;  % random offset along segment, [0.05,0.95] to stop lock-up.
    x3=r*mz(i(1),1)+(1-r)*mz(i(2),1); % somewhere between lowest two
    
    [fx3,cc3,ii]=fobj(x3);
    objx(cnt,:)=fx3;     % record it
    chromx(cnt,:)=x3;
    consx(cnt,:)=cc3;
    infx(cnt,:)=ii; % store eval
    mz(cnt+1,:)=[x3 aggfcn(fx3,tv) min(cc3.*cw)];  % evaluate aggregation
    cnt=cnt+1;  % track

end

mh=mz(:,2);
c=mz(:,3);  % all constraint values
if(sum(c>0))
    mh(c<=0)=mh(c<=0)+max(mh(c>0))+eps;   % make constrained worst
end
[f,i]=sort(mh);  % get lowest values
x=mz(i(1),1);
