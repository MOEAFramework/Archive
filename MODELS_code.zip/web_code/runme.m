%
% runme.m demonstration harness for MODELS algorithm
%
% E.J.Hughes 6/7/2011
%

% The models algorithm has been written in a functional 
% form to allow for simple operation with a range of objective 
% functions.

pop=50;  % intial population size (i.e. intial random search)
neval=2000;  % total number of function evaluations to do

archivesize=30; % size of archive to use

%% tricky highly constrained problem with 5 disconnected regions
x=modelsf(@nobj1, 100, neval,[],[],[],[],[],2);

disp('Press a key to continue');
pause

%% the highly constrained OSY problem; reference point and scale provided
x=modelsf(@objosy, 150, neval,[-300 0;2 1],[],[],[],[],2);

disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D

nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search
x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,[],[],[],2);

disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D
% only graphics displayed at the end.
nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search
x=modelsf(@(x) objhigh(x,nobj), pop ,neval,[],tv,[],[],[],1);

disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D
% restricted target vector set; search 3 regions
nobj=2;
tv=vspace(33,[1 0;1 0.3],0);    % generate target vectors for search
tv=[tv;vspace(33,[0 1; 0.4 0.9],0)];    % generate target vectors for search
tv=[tv;vspace(33,[0.8 0.6; 0.6 0.7],0)];    % generate target vectors for search
x=modelsf(@(x) objhigh(x,nobj), pop ,neval,[],tv,[],[],[],2);

disp('Press a key to continue');
pause


%% the sphere constrained test function run in 2D
% using 10 points in line search rather than default 5
% also using 3 points for gradient estimation rather than none
% also providing an alternative gradient delta value.

nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search
x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,[],[10 3 0.01],[],2);

disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D
% using 5 points in line search using 3 points for gradient
% estimation rather than none
% also providing an alternative gradient delta value.
% only uses weigthed min-max (Chebychev)

nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search
x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,{'wmm_agg'},[5 3 0.01],[],2);

disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D
% using 5 points in line search using 3 points for gradient
% estimation rather than none
% also providing an alternative gradient delta value.
% only uses weigthed min-max (Chebychev)
% uses random search on the line not golden section

nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search

x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,{'wmm_agg'},[5 3 0.01],@morandsrch,2);
disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D
% using 5 points in line search using 3 points for gradient
% estimation rather than none
% also providing an alternative gradient delta value.
% only uses weigthed min-max (Chebychev)
% uses a double sided golden section search: caution, not good 
% on problems where the PF is defined by a constraint boundary!

nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search

x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,{'wmm_agg'},[5 3 0.01],@modgoldsrch,2);
disp('Press a key to continue');
pause

%% the sphere constrained test function run in 2D
% using 5 points in line search using 3 points for gradient
% estimation rather than none
% also providing an alternative gradient delta value.
% uses 70% of search between existing points and only 30% based on gradient
% number of evaluations used not quite as many as asked for though.

nobj=2;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search

x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,{'wmm_agg'},[5 3 0.01 0.8],[],2);
disp('Press a key to continue');
pause

%% the sphere constrained test function run in 5D

nobj=5;
tv=vspace(archivesize,nobj,0);    % generate target vectors for search
x=modelsf(@(x) objhigh(x,nobj), pop,neval,[],tv,[],[],[],2);


