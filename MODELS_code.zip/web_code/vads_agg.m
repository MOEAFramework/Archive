%
% Vector-Angle Distance Scaling aggregation function.
%
% Calling with [tv,R]=vads_agg(obj,[],V) uses 'obj' as 
% new target vector directions and returns the target 
% vectors in 'tv' and the corresponding metrics in 'R'
%
% calling with m=vads_agg(obj,tv,V) will generate the metric
% vector 'm' for the objectives 'obj' against the corresponding
% target vectors  in 'tv'.  Note, obj and tv must be the same size.
% if one target vector is being used, it must be repeated so the matrices
% are of the same dimensions.
%
% V is the 'sharpness' of the probe.  V=10 is blunt, V=50 is not so blunt, 
% V=100 is usually a good choice and is sharp enough to find a reasonable 
% objective surface, without promoting too many bad solutions.
% If a very sparse non-dominated surface is being gathered with very few
% target vectors being used, then it may be wise to reduce V to smooth the 
% resulting objective surface.
%
% The parameter V is best passed in using an anonymous function call.
%
% E.J.Hughes September 2006

function [tv,R,name]=vads_agg(obj,tv,V)    

nobj=size(obj,2);
if(nargout==3)    % if three outputs, we want name of function
    name='VADS';
    tv=[];
    R=[];
    return;
end
if(nargout==2)                     % new vector calculation
    lv=sqrt(sum(obj.^2,2));           % target vector length
    tv=obj./(lv(:,ones(1,nobj))+eps); % unit length target vector
    R=lv;                             % metric that would be seen for vector on self
else                               % set update calculation
    t=sum(obj.*tv,2);                 % find projection of set onto target vector
    lv=sqrt(sum(obj.^2,2));           % target vector length
    Q=t./(lv+eps);                    % cos(angle)
    tv=lv./(Q.^V+eps);                % VADS metric
end