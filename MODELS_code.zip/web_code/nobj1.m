%
% Constrained multi-objective problem
%
% Problem has 5 valid regions, none overlap in x and y
% causing crossover a few problems.  Pareto front is concave
% and in smallest region.  Constrained region gives no 
% direction information.
%
%
% E.J.Hughes August 2001
%
% objecive func 25/4/2003

function [obj,c,ub,lb]=nobj1(Chrom,flaag)

nobj=2;                           % 2 objectives
ncons=2;                          % 2 constraints 

ub=[1 1];  % upper bound on genes
lb=[0 0];  % lower bound on genes

if nargout==4
  obj=nobj;
  c=ncons;
  return;
end

[popsize,nvar]=size(Chrom);

% Loop for all chromosomes 

obj=zeros(popsize,nobj);
c  = ones(popsize,ncons);      % all unconstrained to start

for hjj=1:popsize

  chrom=Chrom(hjj,:).*[1.2 1.6]-[.2 1]; ll=[.2 1]; % 0-1 now [-0.2,1] & [-1 0.6] easy
%  chrom=Chrom(hjj,:).*[12 12]-[2 2]; ll=[2 2]; % 0-1 now [-2,10] hard

  x=chrom(1);
  y=chrom(2);

  p=([0.5 0.8;-0.65 0.5])*[x;y]; % rotate

  q=0.5*floor([2*x;2*y.^3]);
  k1=-1000*(sqrt((p-q)'*(p-q))-0.2);
  k2=(x+0.1)^2+(y+0.8)^2-0.01;
  c(hjj,:)  = [k1  k2];
  obj(hjj,:)= ll+[x y];    % objective values

end
  
