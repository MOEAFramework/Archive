%
% mosgoldsrch.m   does many objective single sided golden section line search
%
% E.J.Hughes 1/9/2010
% MO and single sided mods 28/1/2011
% infx is the capture of the chromosome information
%
% designed to tolerate crappy functions.

function [x,f, objx, chromx, consx infx]=mosgoldsrch(fobj, fx1, N, lb,ub,nvar,aggfcn,tv,cc1)
% fx1 is fitness of initial trial point that lies on search line
% N is number of function evals to do
% ub and lb are the scale factors for left/right on x vector, lb not used.

nobj=length(tv);  % number of objectives
ncons=length(cc1); % number of constraints

cw=rand(1,ncons)+0.01;
cw=cw./max(cw);   % generate a random weighting vector for constraints.

t=(1+sqrt(5))/2;  % golden ratio
tr=1/t;           % reciprocal of it
objx=zeros(N,nobj);
consx=zeros(N,ncons);
chromx=zeros(N,1); % storage for my evals
infx=zeros(N,nvar); % storage for my chrom info

%do far side first (ub):
cnt=2; % count number of function evals
x1=0;  % one point in centre

[fxl,ccl,ii]=fobj(ub);    % also need to store all other evals too for EA use             
objx(1,:)=fxl;
chromx(1,:)=ub; % store eval
consx(1,:)=ccl; % store eval
infx(1,:)=ii; % store eval

x2=ub;
fx2=fxl;
cc2=ccl;  % set edge point

% find bounds first....
% need to track the 'interior points', so generate the pair...

x3=x2-tr*(x2-x1);   % golden section for one interior point to start
x4=x1+tr*(x2-x1);   % golden section for 2nd.
[fx3,cc3,ii]=fobj(x3);
[fx4,cc4,ii]=fobj(x4);
objx(cnt,:)=fx3;     % record it
chromx(cnt,:)=x3;
consx(cnt,:)=cc3;
infx(cnt,:)=ii; % store eval
cnt=cnt+1;  % track
objx(cnt,:)=fx4;     % record it
chromx(cnt,:)=x4;
consx(cnt,:)=cc4;
infx(cnt,:)=ii; % store eval
cnt=cnt+1;  % track


% do search: discard highest outside point and generate new interior
while(cnt<=N)

    ind=double(min(cc1.*cw)>0) + double(min(cc2.*cw)>0);  % 0 if both cons, 1 if only one 2 if ok.
    flaag=0;  % indicate take 1 winning as default
    switch(ind)
        case 0
            % both constrained, largest min wins
            if(min(cc1.*cw)<min(cc2.*cw))
                flaag=1;   % 2 wins
            end
        case 1
            % one is constrained
            if(min(cc2.*cw)>0)
                flaag=1;  % 2 wins
            end
        case 2
            if (aggfcn(fx1,tv)>aggfcn(fx2,tv))
                flaag=1;  % 2 wins
            end
    end
        
    % do swaps based on choice
    if(flaag==1)
        % drop x1, x3->x1
        % x4-> x3
        % x2=x2
        % calc new x4
        x1=x3;
        fx1=fx3;  % x3 moves to x1
        cc1=cc3;
        x3=x4;
        fx3=fx4;  % x4 moves to x3
        cc3=cc4;
        
        x4=x1+tr*(x2-x1);   % golden section for 2nd.
        [fx4,cc4,ii]=fobj(x4);
        objx(cnt,:)=fx4;     % record it
        chromx(cnt,:)=x4;
        consx(cnt,:)=cc4;
        infx(cnt,:)=ii; % store eval
    else
        % drop x2, x4->x2
        % x3-> x4
        % x1=x1
        % calc new x3
        x2=x4;
        fx2=fx4;  % x3 moves to x1
        cc2=min(cc4);
        x4=x3;
        cc4=min(cc3);
        fx4=fx3;  % x4 moves to x3
        x3=x2-tr*(x2-x1);   % golden section for 2nd.
        [fx3,cc3,ii]=fobj(x3);
        objx(cnt,:)=fx3;     % record it
        chromx(cnt,:)=x3;
        consx(cnt,:)=cc3;
        infx(cnt,:)=ii; % store eval
    end
    
    cnt=cnt+1;   % count the evaluation
end

x=[x1 x3 x4 x2];
f=[aggfcn(fx1,tv) aggfcn(fx3,tv) aggfcn(fx4,tv) aggfcn(fx2,tv)];
