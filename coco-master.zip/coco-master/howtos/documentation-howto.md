The documentation of the COCO platform moved to the coco-doc repository lately. See [there](https://github.com/numbbo/coco-doc/blob/gh-pages/documentation-howto.md) for details.
