%
% objzdt1.m
%
% Example of ZDT1 objective function - 30 variables
%
% call with 4 outputs to get the number of objectives, constraints and
% upper/lower bound on decision variables.
% call with 2 outputs to get evaluation.
%
% E.J.Hughes 16/3/2006

function [obj,c,ub,lb]=objzdt1(Chrom,flaag)

nobj=2;                           % 2 objectives
ncons=0;                          % 0 constraints 

nvar=30;          % 30 variable problem
ub=ones(1,nvar);  % upper bound on genes (Nvar gene problem)
lb=zeros(1,nvar); % lower bound on genes

if nargout==4     % return problem dimensions if requried
  obj=nobj;
  c=ncons;
  return;
end


[popsize,nvar]=size(Chrom);


% Loop for all chromosomes 

obj=zeros(popsize,nobj);
c=[];
for hjj=1:popsize

    chrom=Chrom(hjj,:);  %local copy of chromosome
    x=chrom(1);
    g = sum(chrom(2:end)); % ZDT1 objectives
    g = 9.0*g/(nvar-1)+1;
    h = 1.0 - sqrt(x/g);
    f2 = g*h;
    
    obj(hjj,:)=[x f2];    % return objectives
    %  c(hjj,:)  = 1;
end

