%
% objpri.m
%
% Objective function that calls testpris.p function
% and provides objectives to be minimised
% Decision vector space is re-mapped into (0,1] interval.
%
% if function is called as [o,c,ub,lb]=objpri([])
% returns:
% o = number of objectives
% c = number of constraints
% ub = vector of upper decision variable bounds
% lb = vector of lower decision variable bounds
% and will default to 8 PRFs.
% if function is called as [o,c,ub,lb]=objpri([],N)
% it will return the above, but the number of PRFs will be N.
%
% if function is called as [o,c]=objpri(chromosomes)
% then it will default to 8 PRFs and return the objectives matrix in 'o'
% and the constraint matrix in 'c' (all set to 1's to allow full set to be
% explored).
%
% if function is called as [o,c]=objpri(chromosomes,N)
% then the objectives will be returned as above, but for N PRFs.
%
% E.J.Hughes 25/7/2006

function [obj,c,ub,lb]=objpri(chrom,npri)

if(nargin==1)
    npri=8;    % set default to a 8 PRI/PRF system
end

% These lines define the upper/lower bounds on decision space.
% This function allows range (0,1] to be used by optimiser for simplicity
ub=ones(1,npri);% upper bound on genes
lb=eps+zeros(1,npri);% lower bound on genes

nobj=9;                 % no. of objectives
ncons=1;                % no. of constraints, put a dummy constraint in. 

% if function is called as [o,c,ub,lb]=objpri()
% returns:
% o = number of objectives
% c = number of constraints
% ub = vector of upper decision variable bounds
% lb = vector of lower decision variable bounds
if nargout==4
  obj=nobj;
  c=ncons;
  return;
end

[popsize,nvar]=size(chrom);  % chrom is array of chromosomes

obj=zeros(popsize,nobj);      % allocate output space for objectives
c=ones(popsize,ncons);        % allocate output space for constraints
for n=1:popsize               % loop for all
    [obj(n,:),c(n,:)]=objfcn(chrom(n,:));  % calculate objective
end

    
% acutal objective function
function [o,c]=objfcn(chrom)

pri=round(chrom*1000)+500;  % build correct PRI set values from chromosome
                            % PRI=1/PRF of course.

o=testpris(pri);     % calculate metrics
%o=testpris(pri,1);  % calculate metrics, if optional argument is non-zero,
%will also draw graphs of decodablity and blindability curves, of which the
%first 8 objectives are the minimum and median values.

o=[-o(1:8) o(9)-50]; % arrange all for minimisation, with a maximum of 
                     % zero for being valid
c=1;                 % constraint ok if >=0, invalid otherwise.
                     % constraint is used as a dummy here to allow full set
                     % to be created.
