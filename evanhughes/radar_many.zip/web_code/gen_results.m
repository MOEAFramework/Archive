%
% gen_results.m   Analyse results of EA runs
%
% E.J.Hughes 15 October 2006

rss=cell(1,3);  % results sets
% nsga2 results of 30 runs of p=100,200 gens
load 121006a dta   
rss{1}=dta;    % cell array of objectives and chromosomes

%prototype CAAOS, results of 30 runs of p=20,000 evals
load 121006b dta
rss{2}=dta;    % cell array of objectives and chromosomes

%bug-corrected MSOPS results of 30 runs of p=100,200 gens
load 171006a dta 
rss{3}=dta;
%for n=1:30
%    rss{3}{1,n}=rss{3}{1,n}{1};  % cell array of objectives for weighted min-max
%    rss{3}{2,n}=rss{3}{2,n}{1};  % cell array of chromosomes for weighted min-max
%end    
% make total reference set, then find upper/lower bounds and scale of
% surface

fs=[];

for n=1:3
    n
    for m=1:30
        fs=[fs;rss{n}{1,m}];         % objectives
    end    
end % end of n

kref=min(fs)-eps % reference point
krng=max(fs)-min(fs)+eps;  % reference scaling of objectives

% now perform 10 sets of 200 samples of median attainment surface.
% 200 points are a very sparse sample in 9 dimensions, so repeating with 
% different sets of 200 points will allow 95% confidence bounds to be
% estimated.

% create storage for results.
ddt=cell(1,3);
ddt{1}=zeros(10,200);  % NSGA2
ddt{2}=zeros(10,200);  %CAAOS
ddt{3}=zeros(10,200);  %MSOPS

for jj=1:10

    jj
wmtx=vspace(200,9);   % generate 200 weight vectors, approximately uniformly
                      % spread over the 9D region, but different from 
                      % trial- to - trial.
qq=cell(1,3);         % Temporary storage

for n=1:3             % loop over the three methods
    n
    qq{n}=cell(1,30)  % storage for results from each method
    for m=1:30        % loop over all 30 trials of each algorithm
        k=zeros(1,200);
        for h=1:200   % loop over all target weight vectors
            ii=ones(size(rss{n}{1,m},1),1);   % vector of 1's to simplify next line.
            % calculate weighted-min-max metric -> will give non-dominated
            % surface.  Make sure objectives normalised first to prevent
            % scaling errors, i.e non-uniform spread of weight vectors.
            k(h)=min(wmm_agg((rss{n}{1,m}-kref(ii,:))./krng(ii,:),wmtx(h*ii,:)));  
        end
        qq{n}{1,m}=k  % store results
    end    
end % end of n

% re-arrange results from cell array, and then calculate median
% attainment surface sample points
dzd=zeros(3,200);
for n=1:3
    tt=zeros(30,200);
    for m=1:30
        tt(m,:)=qq{n}{1,m};
    end    
    dzd(n,:)=median(tt);
end % end of n

%plot these results for this itteration.
figure(1)
plot(sort(dzd,2)')
grid
drawnow

% store results for this itteration
ddt{1}(jj,:)=sort(dzd(1,:));
ddt{2}(jj,:)=sort(dzd(2,:));
ddt{3}(jj,:)=sort(dzd(3,:));

end

%% plot figures of the median attainment surfaces now.
figure(1)
plot(1:200,median(ddt{1}),'-',1:200,median(ddt{2}),'-.',1:200,median(ddt{3}),'--')
xlabel('Sorted vectors index')
ylabel('Weighted min-max metric value')
title('Distribution of metric values')
grid
legend('NSGA-II','CAAOS','MSOPS')
d1=sort(ddt{1});
d2=sort(ddt{2});
d3=sort(ddt{3});
hold on
plot(1:200,d1(2,:),'b:',1:200,d1(9,:),'b:')
plot(1:200,d2(2,:),'g:',1:200,d2(9,:),'g:')
plot(1:200,d3(2,:),'r:',1:200,d3(9,:),'r:')
hold off



figure(2)
plot(1:200,median(ddt{1}),'-',1:200,median(ddt{2}),'-.',1:200,median(ddt{3}),'--')
xlabel('Sorted vectors index')
ylabel('Weighted min-max metric value')
title('Distribution of metric values')
grid
legend('NSGA-II','CAAOS','MSOPS')

figure(3)
plot(fs(1:1000,:)')
grid
xlabel('Objective Number')
ylabel('Objective Magnitude')
title('Raw objectives')

figure(4)
ll=size(fs,1);
nn=(fs-kref(ones(ll,1),:))./krng(ones(ll,1),:);
plot(nn(1:5000,:)')
grid
xlabel('Objective Number')
ylabel('Normalised Objective Magnitude')
title('Normalised objectives')

figure(5)
plot(nn(1:1000,1),nn(1:1000,2),'.')
grid
xlabel('Objective 1, Median Range Decodability')
ylabel('Objective 2, Median Velocity Decodability')
title('Normalised objectives')

figure(6)
imagesc(sortrows(nn(1:10000,:)))
grid
xlabel('Objective Number')
ylabel('Solution Index')
title('Normalised objectives')
colorbar
