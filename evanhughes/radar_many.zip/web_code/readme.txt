
This zip-file contains the matlab 7 software for the 9-objective radar design problem.

The software is distributed under a free license for academic use only and no liability will be accepted for any issues that arise through its use.  Please contact the author if the software or concepts contained in these files are to be used for financial gain, and terms can be negotiated.


The files that relate to the objective are:

testpris.p     % matlab p-code file that does actual objective calculations
objpri.m       % matlab function used as an example driver file for testpris.p

Also the beta version of the MSOPS-II algorithm is provided so that objective surfaces can be generated from the objective function.  The algorithm is called Adaptive Archiving Multiple Single Objective Pareto Sampling and is a true many-objective optimiser, based on a non-Pareto ranking system.  The beta version
includes solution archiving, and also automatic weight-vector generation, allowing efficient optimisation of unseen functions.  The algorithm will also perform constraint handling and auto scaling and reference point generation, allowing objective values to go negative.  The algorithm will generate both a non-dominated surface, and the objective surface, allowing discontinuties to be identified.  Example code is also provided within the algorithm to fix the set of weight vectors and explore the edges of the objective region and surface shape too. 
The files are:

aamsops_ep2.m   % main MSOPS-II algorithm code
wmm_agg.m       % weighted min-max aggregation function for finding non-dominated set
vads_add.m      % vector-angle distance scaling aggregation function for finding objective surface
vspace.m        % function for generating sets of weight vectors based on fixed definitions. 
parset.m        % function for identifying non-dominated surface from objective matrix

objzdt1.m       % example 2-objective ZDT1 function (optional)
objmocons.m     % example 2-objective, 2 constraint Tanaka objective function (optional)

The software for generating the results in the paper are also provided.  The files are:

tim_test.m      % performs 10 repeats of 10,000 evaluations of testpris.p to establish processing time.
pri_driver.m    % performs 30 trials of the MSOPS algorithm on testpris.p

gen_results.m   % performs analysis of NSGA2, AAMSOPS and CAAOS algorithm results and generates figures for paper
121006a.mat     % NSGA-II non-dominated sets from 30 trials
121006b.mat     % CAAOS non-dominated sets from 30 trials
171006a.mat     % AAMSOPS non-dominated sets from 30 trials 

NOTE: the 3 .mat files are not included to keep zip size small.  They are linked separately from the web page.  The results in the paper were also generated over a decision space range of [500 2000] instead of [500 1500], and should only be used with care for visualisation.

The current best-known non-dominated results are provided in comma-separated variable form as <parameter> <objective> for the different numbers of decision variables indicated in the file-name e.g:

Best_set_4pri_10_03_2007.txt

I have also included a PDF of the paper in the zip, and a pdf copy of the poster that was presented at EMO2007, Japan

The 'testpris.p' file has now been updated to operate with the more recent versions of Matlab (e.g. 2019a release).

    Evan J Hughes

      3rd February 2020

evan@whradar.com