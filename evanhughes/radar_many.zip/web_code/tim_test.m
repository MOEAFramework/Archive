% tim_test.m
% tests run-time of objective function.
% performs 10 repeats of 10,000 evaluations
% and returns median results -allows for multi-tasking effects
% the timings are calculated for 4, 8 and 12 decision variables.

% E.J.Hughes 12/10/06

tx4=zeros(1,10);
tx8=zeros(1,10);
tx12=zeros(1,10);   % storage for results

o=testpris(round(rand(1,4)*1001+500)); % pre-load function into memory

for n=1:10
    vt=round(rand(10000,4)*1001+500);  % random decision vectors to test
    tic                                % start clock
    for m=1:10000
        o=testpris(vt(m,:));           % evaluate
    end
    tx4(n)=toc;                        % record time
end
    
median(tx4)                            %output time for 10000 evals, 4 gene

for n=1:10
    vt=round(rand(10000,8)*1001+500);  % random decision vectors to test
    tic
    for m=1:10000
        o=testpris(vt(m,:));           % evaluate
    end
    tx8(n)=toc;
end

median(tx8)                           %output time for 10000 evals, 8 gene

for n=1:10
    vt=round(rand(10000,12)*1001+500);
    tic
    for m=1:10000
        o=testpris(vt(m,:));
    end
    tx12(n)=toc;
end

median(tx12)                          %output time for 10000 evals, 12 gene
