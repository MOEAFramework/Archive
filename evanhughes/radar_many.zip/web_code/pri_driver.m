%
% pri_driver.m  Runs aamsops_ep2 repeat experiments.
%
% E.J.Hughes 12/10/2006

fname='171006a';      % file-name for saves
txxq=clock;           % grab start time
dta=cell(2,30);
for nfx=1:30
    nfx
    aamsops_ep2;       % perform and optimisation run
    dta{1,nfx}=Bobj;   % record all objectives
    dta{2,nfx}=Bchrom; % record all decision variables
    dta
eval(['save ' fname])  % save results
end
toc
txxq2=clock;
etime(txxq2,txxq)  % elapsed time

eval(['save ' fname])
