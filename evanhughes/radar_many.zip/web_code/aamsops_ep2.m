%
% aamsops_ep2.m 
% Adaptive Archiving Multiple Single Objective Pareto Sampling 
%
% Multi-objective optimisation using multiple single objectives
%
% Uses search vector and angle control.  Weight vector is search direction
%
% Uses EP style xovr/mutation process.  Simple self adaptive mutation.
%
% constraints return -ive if bad. 0 or +ive for good.
% this is flipped for internal storage!
%
% E.J.Hughes 4/6/2003 original MSOPS
% December 2003 auto reference point and scaling added.
% January 2006 Adaptive Archiving variant to find target vector set.
% modified for better code structure  October 2006


%% parameters common to all EAs
gflaag=1;            %=0 no figures, =1 figures at end only =2 figures each gen

p=100;                % population size
maxgen=200;          % number of generations
nwt_max=100;          % number of target vectors.

%f_obj=@objzdt1;         % ZDT1 2 objective objective function
%f_obj=@objmocons;        % Tanaka 2 objective function
f_obj=@(x)objpri(x,8);  % Radar PRI set design 9 objective function


fixed_v=0;               % set to 1 if fixed vector set needed, =0 for auto
tz_ref=[];               % reference point - empty for auto/default
obj_scale=[];            % scaling of objectives - empty for auto/default
tv_init=[];              % target vector set - empty for auto/default

% example of fixed analysis for use with objmocons (tanaka)
%fixed_v=1;               % set to 1 if fixed vector set needed, =0 for auto
%tz_ref=[0 0];            % reference point - empty for auto/default
%obj_scale=[1 1];         % scaling of objectives - empty for auto/default
%tv_init=[10 0.5 1];       % target vector set - use a 5 degree cone about [0.5 1]

% example fixed analysis set for use with objpri
% creates a 2D 'fan' through the high-dimensional space to allow the curvature
% of the surface to be analysed - convex or concave? any holes?
%
% figure 1000 shows how close soltuions were found to the desired targets -
% anything greater than about 5 degrees probably shot past the objective
% region!
% The objective magnitude figures 1001+ will show how well the sorted
% weight vectors were attained.  Beware, distances for vectors that went
% beyond the objective region usually are junk values.
% It is worth also monitoring the tz_ref_error reported at the end - any
% negative values indicates that the tz_ref point lies within the objective
% region!  All results are liable to be suspect if this is the case.
%
% the set tv_init=[1 0 0 0 0 0 0 0;0 1 1 1 1 1 1 1 1]; was tried first (set 1), but
% only 15 vectors really went through the objective region (based on figure 1000),
% so the fan was trimmed to just the lower end where solutions seem to
% exist. 
% the results from set 2 are better, but show a series of 
% minima, which is typical of Pareto sets where only spot solutions
% have been found, i.e. it does not look continuous.  The objective
% profiles in figs 1001+ then have characterisic 'flats' where the same
% solution is satisfying many of the weight vectors (and hence the
% increasing x^2 looking angles in fig 1000).  It is also interesting to
% note that in fig 1000, the WMM and VADS have converged to different
% locations - it looks as if there is a very sharp curve in the objective
% surface in this region and the VADS metric is just 'clipping' the ridge
% or side of the function.  This is borne out further in the 1001+ plots
% where the VADS metric is closer to the reference point than the weighted
% min-max!  The surface must be approaching a discontinutity? - the wmm
% values have 'junk' in and are deviating from the VADS solutions...
% Additionally, the error is still all greater than 1 degree in figure
% 1000, which suggests that the fan of vectors is very close, but does not
% quite pass through the objective space...
%
% set 3 attempts to focus further by using the ff_best report from the
% analysis which is the direction of the solution that was closest to any
% of the weight vectors.  This is useful for 'homing in' on a solution
% cluster region.  A small 2 degree window was applied in an attempt to
% home-in on the objective space.

% all 3 sets need these 5 lines:
%p=50;                % population size: reduced search for speed.
%maxgen=150;          % number of generations
%nwt_max=50;          % number of target vectors.
%fixed_v=1;           % set to 1 if fixed vector set needed.
%tz_ref=1e4*[-0.6450   -0.0061   -2.1430   -0.03   -0.2070   -0.003   -0.7137   -0.0094   -0.002]*1.1;   % objective offset point for target vectors

% set 1: full fan, uncomment these lines
%obj_scale=1e4*[0.5400    0.0055    1.6843    0.0136    0.2145    0.0024    0.9182    0.0092    0.0068];  % scaling for objectives when spread
%tv_init=[1 0 0 0 0 0 0 0 0;0 1 1 1 1 1 1 1 1];  % generate a fan profile

% set 2: restricted fan, uncomment these lines
%obj_scale=[];  % scaling for objectives when spread
%tv_init=[0.0000 0.0028 0.8725 0.0070 0.1111 0.0012 0.4757 0.0048 0.0035;
%  0.4070 0.0026 0.7970 0.0064 0.1015 0.0011 0.4345 0.0044 0.0032];  % generate a fan profile

%set 3: spot target with small angular spread, uncomment these lines
%obj_scale=[];  % turn off scaling when direct targeting as may move vector directions.
%tv_init=[2   0.2045    0.0042    0.8440    0.0239    0.1010    0.0027    0.4846    0.0076    0.0060];  % generate a 2 degree cone.


%% parameters for this technique - Evolutionary Programme
Nct= 5;      % number in tournament to find close solution to cross
xovr=1;      % crossover rate
mutr=1;      % probability of mutation occuring
tau=[];      % mutation adaption - empty for auto setting.
V=100;       % VADS scaling factor 

scale_flaag=1;  % allows vector spread based on actual objective scalings.

aggmthd={@wmm_agg, @(obj,tv)vads_agg(obj,tv,V)};  % array of aggregation function handles
%aggmthd={@(obj,tv)vads_agg(obj,tv,V)};  % VADS only so objective surface
%aggmthd={@wmm_agg};  % weighted min-max only so non-dominated set only


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%% Main code
% seed random numbers from system clock
tic
rand('state',sum(100*clock));
randn('state',sum(100*clock));

[nobj,ncons,ub,lb]=f_obj([]);  % blank call to objective to get sizes
rloc=0.1^(1/maxgen);      % reduction factor to force some convergence

nwt=nwt_max;
if(fixed_v)
    disp('Generating target vectors')
    if(isempty(tv_init)) tv_init=nobj; end
    wmtx=vspace(nwt_max,tv_init);   % create target weight vector set for msops.
     if(~isempty(obj_scale))  % make sure even spread dispite dissimilar objectives
         wmtxn=wmtx.*(obj_scale(ones(nwt,1),:)+eps);  % normalise for spread
         sxn=sqrt(sum(wmtxn.^2,2))+eps;   % magnitude
         wmtx=wmtxn./sxn(:,ones(1,nobj));  % make sure length ==1 again
     end
                    
    if(isempty(tz_ref)) 
        tz_ref=zeros(1,nobj);  % no basic correction to objectives
    end
else
    wmtx=[];  % empty set to fill automatically
end

%% initialise population and variables

bnd=[ub;lb];   % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene
nvar=size(bnd,2);           % number of variables
sigma=rng/8;                %base standard deviation

if(isempty(tau))
    tau=1/sqrt(2*nvar);   % mutation evolution rate, smaller = slower
end

sgx=ones(p,1);               % baseline mutation size array
chx=rand(p,nvar).*(ones(p,1)*rng)+ones(p,1)*bnd(2,:);
                            % initial pop. lb<= x <=ub
gen=0;                      % generation counter

nmth=length(aggmthd);       % number of aggregation methods
R=cell(1,nmth);
tv=cell(1,nmth);
mvall=cell(1,nmth);   % index lists for aggregation functions
Bobj=cell(1,nmth);
Bcons=cell(1,nmth);
Bchrom=cell(1,nmth);
obj=[];
cons=[];
chrom=[];
sg=[];


%% Main loop

disp('Running ..')

while(gen<maxgen)        
    
    [objx,consx]=f_obj(chx);     % evaluate
    consx=-consx;   % flip constarints !!
    
    if(ncons==0)
        consx=zeros(size(objx,1),1);
    end

    if(isempty(tz_ref)  && sum(sum(consx>0,2)==0)~=0) % see if have valid points
        tz_ref=min(objx(sum(consx>0,2)==0,:),[],1)-eps;  % determine initial reference point for objectives
    end

    if(~fixed_v && sum(sum(consx>0,2)==0)~=0)
        fmsk=min(objx(sum(consx>0,2)==0,:))<tz_ref; % see if reference must move: need to consider constrained and good.
        if(sum(fmsk)>0)
            tz_ref=min([tz_ref;objx(sum(consx>0,2)==0,:)],[],1);  % move reference
            % need to re-calc metric vectors now:
            for z=1:nmth  % do not need to do constrained set here as not objectives.
                fnh=aggmthd{z};   % temp function handle to stop interpreter errors
                if(~isempty(Bobj{z}))
                    [tv{z},R{z}]=fnh(Bobj{z}-tz_ref(ones(length(R{z}),1),:),[]);  % call aggregation functions
                end
            end        
        end
    end

    if(sum(sum(consx>0,2)==0)~=0)
        % need to build objective surface to establish weight vectors:
        for z=1:nmth
            mvall{z}=[sum(consx>0,2)==0;logical(ones(length(R{z}),1))];  % flags for good/not good
            fnh=aggmthd{z};   % temp function handle to stop interpreter errors
            [tvx,Rx] = fnh(objx-tz_ref(ones(p,1),:),[]);  % call aggregation functions
            tv{z}=[tvx;tv{z}];
            R{z}=[Rx;R{z}];
            Bobj{z}=[objx;Bobj{z}];                       % concatenate old obj with new
            Bcons{z}=[consx;Bcons{z}];                    % concatenate old constraint with new
            Bchrom{z}=[chx;Bchrom{z}];                    % concatenate old & new chroms
        end
        
        %test to see if on objective surface...
        for n=1:p
            
            %skip if constrained
            if(sum(consx(n,:)>0,2)~=0)
                continue;
            end
            %calculate metric
            
            for z=1:nmth
                if(~mvall{z}(n)) % either constrained or already classed as poor
                    continue;
                end
                mvall{z}(n)=logical(0);   % signal this point is probably bad (also stops self compare)
                vl=sum(mvall{z});    % list length
                if((vl==0))  % empty set, therefore there was one good one!
                    mvall{z}(n)=logical(1);   % signal this point is the only one
                    continue;
                end
                % all points on set compared to this new target vector
                fnh=aggmthd{z};   % temp function handle to stop interpreter errors
                m=fnh(Bobj{z}(mvall{z},:)-tz_ref(ones(vl,1),:),tv{z}(n*ones(vl,1),:));  % call aggregation functions
                if(min(m)>R{z}(n))  % all beaten on new test vector, therefore good
                    % need to see if we need to remove any - they are
                    % beaten by new point on thier own vector
                    % this point in set solution good, tested on all existing vectors
                    m=fnh(Bobj{z}(n*ones(vl,1),:)-tz_ref(ones(vl,1),:),tv{z}(mvall{z},:));  % call aggregation functions
                    idx=m<=R{z}(mvall{z}); % get any that are beaten
                    mvall{z}(mvall{z})=~idx;  % cut if beaten, remove their contribution too
                    mvall{z}(n)=logical(1);   % signal this point on objective front
                end
            end
        end
        
        % capture objective surface
        
        Bobjo=Bobj;
        Bchromo=Bchrom;  % copy of old set.
        Bconso=Bcons;  % copy of old set.
        
        % get range of best objectives for scaling vectors to
        obj_scale=zeros(1,nobj)+eps;;
        for z=1:nmth  % do not need to do constrained set here as not objectives.
            qt=Bobj{z}-tz_ref(ones(size(Bobj{z},1),1),:);
            obj_scale=max(obj_scale,max(qt,[],1));   % get range of objectives
        end
        
        for z=1:nmth
            % new values
            R{z}=R{z}(mvall{z});
            tv{z}=tv{z}(mvall{z},:);
            Bobj{z}=Bobj{z}(mvall{z},:);
            Bcons{z}=Bcons{z}(mvall{z},:);
            Bchrom{z}=Bchrom{z}(mvall{z},:);
        end
        
        
        if(~fixed_v)
            % update target vectors...
            for n=1:size(tvx,1)
                
                % skip if constrained
                if(sum(consx(n,:)>0,2)==0)
                    
                    wmtx=[wmtx;tvx(n,:)]; % tag on
                    nwt=size(wmtx,1);
                    % add in if still too small
                    if(nwt<nwt_max)
                        continue;
                    end
                    
                    npx=zeros(nwt,nwt);
                    if(scale_flaag)  % make sure even spread dispite dissimilar objectives
                        wmtxn=wmtx./(obj_scale(ones(nwt,1),:)+eps);  % normalise for spread
                        sxn=sqrt(sum(wmtxn.^2,2))+eps;   % magnitude
                        wmtxn=wmtxn./sxn(:,ones(1,nobj));  % make sure length ==1 again
                    else
                        wmtxn=wmtx; % or just spread as is
                    end
                    for nn=1:nwt
                        npx(:,nn)=wmtxn*wmtxn(nn,:)'; % dot product
                    end
                    npx=npx.*(1-eye(size(npx))); % ignore self
                    % sort within each row so that closest distance goes to
                    % left, furthest distance goes to right.
                    % then sort rows so that ones with most close are at
                    % top, those most separated are at bottom.  Then take
                    % bottom ones only.
                    [a,mval]=sortrows(sort(1-npx,2)); % find those that have most close
                    wmtx=wmtx(mval(end-nwt_max+1:end),:);     % cut most crowded
                    nwt=size(wmtx,1);
                end
                
            end
        end
        
        objx=[obj;objx];                       % concatenate old obj with new
        consx=[cons;consx];                    % concatenate old constraint with new
        chx=[chrom;chx];                       % concatenate old & new chroms
        sgx=[sg;sgx];                          % concatenate old & new mutation spreads
    end
            
  
%% apply constraints

mcon=sum(consx>0,2)==0;  % mask of those satisfying constraints
objxx=objx(mcon,:);     % get good solutions
[tmp,iob]=min(objxx,[],1);   % get the very best in each objective
objxx(iob,:)=[];        % remove as these will be classified separately
nvalid=size(objxx,1);

 % generate multi-objective ranking using MSOPS process
 ii=[];
 for z=1:nmth
      nrx=zeros(nvalid,nwt);
      fnh=aggmthd{z};   % temp function handle to stop interpreter errors
      for nx=1:nvalid
          m=fnh(objxx(nx*ones(nwt,1),:)-tz_ref(ones(nwt,1),:),wmtx);  % call aggregation functions
          nrx(nx,:)= m';  % metric results.
      end
      [a,iit]=sort(nrx,1);                             % get order of results
      tt=(1:nvalid)';
      for nx=1:nwt
          iit(iit(:,nx),nx)=tt;                  % give correct rank index
      end
      ii=[ii iit];   % concatenate different ranking methods
 end

  %process constrained now
  qj=consx(~mcon,:);         % get constrained solutions
  qj(qj<0)=0;                % clip good bits
  
  qj=sum(qj.^2,2);             % distance squared to valid point
  [a,ic]=sort(qj,1);            % get order of results
  
  sv=sort(ii,2);                  % sort to get score vector of unconstrained
  [a,i]=sortrows(sv);                    % get population rank order
  tt=1:size(objx,1);
  ttv=tt(mcon);                   %indexes of unconstrained
  ib=ttv(iob);
  ttv(iob)=[];                     % correct for very best.
  i=ttv(i);                               % get true index of unconstrained
  ttc=tt(~mcon);
  ic=ttc(ic);                             % true index of constrained
  i=[ib i ic];                     % final rank order.
  
  % get working population for next iteration...
  i(i>2*p)=[];  % ignore entries from archive
  obj=objx(i(1:p),:);                    % take best `p' objectives
  chrom=chx(i(1:p),:);                   % take best `p' chromosomes
  cons=consx(i(1:p),:);                  % take best `p' constraints
  sg=sgx(i(1:p),:);                      % take best `p' sigmas
  sg=sg*rloc;            % reduce the 'end-stops' otherwise they fix

  gen=gen+1;                             % increment counter

  % plot some graphs
  
  % get pareto set
  if(~isempty(obj))
      mm=find(sum(cons>0,2)==0);
      r=parset(obj(mm,:));
      mm=mm(r==1);
      pobj=obj(mm,:);
      pchrom=chrom(mm,:);

      if(gflaag==2 || (gflaag>0 && gen==maxgen))
    
          % plot best surface so far.
          clrz={'b.','ro','k^','g*'};
          if(~isempty(Bobj{1}))
              figure(20)
              for z=1:nmth
                  plot(Bobj{z}(:,1),Bobj{z}(:,2),clrz{z})
                  hold on
              end
              hold off
              grid
              xlabel('Objective 1')
              ylabel('Objective 2')
              title('Current best sets for first two objectives')
          end

          if(gflaag)              
              figure(101)
              plot(sg)
              grid
              xlabel('Individual')
              ylabel('Mutation standard deviation')
              title('Mutation adaptation')
          end

          
          figure(1)
          subplot(3,1,2)
          if(length(mm)>1)
              plot(((pchrom-bnd(2*ones(length(mm),1),:))./rng(ones(length(mm),1),:))') % normalised chromosome values
          end
          grid
          xlabel('Genes')
          ylabel('% Magnitude of best')
          subplot(3,1,3)
          qq=sum(cons>0,2)~=0;
          if(sum(qq))
              plot(((chrom(qq,:)-bnd(2*ones(sum(qq),1),:))./rng(ones(sum(qq),1),:))') % normalised chromosome values
          else plot(0,0)
          end
          grid
          xlabel('Genes')
          ylabel('% Magnitude of constrained')
          subplot(3,1,1)
          plot(((chrom-bnd(2*ones(p,1),:))./rng(ones(p,1),:))') % normalised chromosome values
          grid
          title(['Decision Space, generation ' num2str(gen) ...
              '  Copyright \copyright 2006 Cranfield University'],'fontsize',8)
          xlabel('Genes')
          ylabel('% Magnitude of all')
          
      
          figure(2)
          if(nobj==2)
              Bto=[];
              for z=1:nmth
                  Bto=[Bto;Bobj{z}];
              end
             
              subplot(1,1,1)
              qq=sum(cons>0,2)==0;
              if(sum(qq))
                  plot( ...
                      obj(qq,1),obj(qq,2),'b.', ...
                      obj(~qq,1),obj(~qq,2),'m.', ...
                      Bto(:,1),Bto(:,2),'ro')
                  v=axis;
                  dx=sqrt((v(2)-tz_ref(1))^2+(v(4)-tz_ref(2))^2);
                  hold on
                  for nx=1:size(wmtx,1)
                      plot([tz_ref(1,1);wmtx(nx,1)*dx+tz_ref(1,1)],[tz_ref(1,2);wmtx(nx,2)*dx+tz_ref(1,2)],'r--')
                  end
                  hold off
                  axis(v)
                  xlabel('Objective 1','fontsize',8)
                  ylabel('Objective 2','fontsize',8)
                  grid
              end
          else
              subplot(3,1,2)
              plot(pobj')
              xlabel('Objective')
              ylabel('Best')
              grid
              subplot(3,1,3)
              qq=sum(cons>0,2)==0;
             
              if(sum(~qq))
                  plot(obj(~qq,:)')
              else plot(0,0)
              end
              xlabel('Objective')
              ylabel('Constrained')
              grid
              subplot(3,1,1)
              plot(obj')
              xlabel('Objective')
              ylabel('All')
              grid
              
          end % end figure 2
      
          title(['Objective Space, generation ' num2str(gen) ...
              '  Copyright \copyright 2006 Cranfield University'],'fontsize',8)
          set(gca,'fontsize',8)
          set(2,'PaperUnits','centimeters','PaperPosition',[1 1 12 10]);
                    
          drawnow
      end
  end
  % prepare for next generation
  
  % perform uniform selection, then intermediate crossover
  chx=zeros(p,nvar);   % create storage space for new chrom
  sgx=zeros(p,1);
    
  if(isempty(Bobj))
     % make sure random search if no valid solutions so far 
     chx=rand(p,nvar).*(ones(p,1)*rng)+ones(p,1)*bnd(2,:);
     sgx=ones(p,1);      % storage for mutated sigmas

  else
      fobj=[Bobjo{1}];
      fchrom=[Bchromo{1}];  % elitist strategy for selection
      
      for ki=1:p
          r=ki;
          % do large tournament to find other parents via crowding from archive
          % randomly crowd in objective or decision space
          [tmp,ix]=sort(rand(1,size(fobj,1)));   % generate scrambled index list of archive+pop
          Nca=min(Nct,floor(length(ix)/2));
          ix=ix(1:Nca*2);
          
          dst_o=sum((obj(r*ones(size(ix,2),1),:)-fobj(ix,:)).^2,2);   % euclidean in objective
          dst_c=sum((chrom(r*ones(size(ix,2),1),:)-fchrom(ix,:)).^2,2);     % euclidean in chrom
          if(rand>0.5)                                % mask for obj/chrom
              dst=dst_o;
          else
              dst=dst_c;
          end
          dst=reshape(dst,Nca,2);  % get the index's for the trials
          ix=reshape(ix,Nca,2);  % get the index's for the trials
          
          [tmp,r2]=min(dst,[],1);     % Nct tournament of distance
          r2=diag(ix(r2,:))';          % recast to index
          
          alpha=rand(1,nvar)*1.5-0.25; % create vector of random
          % then crossover
          alti=alpha.*chrom(mod(ki-1,p)+1,:)+(1-alpha).*fchrom(r2(1),:);
              
          chx(ki,:)=chrom(mod(ki-1,p)+1,:);   % just copy if not crossing
          mx=rand(1,nvar)<xovr;
          chx(ki,mx)=alti(mx);      % crossover genes at rate.
          sgx(ki)=sg(ki)*exp(randn*tau);            % mutate mutation size

          sgx(ki)=min(1,sgx(ki));  % crop mutation spreads
  
          % adds Gaussian noise for
          % a mutation with standard
          % deviation of `sigma',
          % if selected based on mutr
          chx(ki,:)=chx(ki,:)+(rand(1,nvar)<mutr).*randn(1,nvar).*(sgx(ki)*sigma);
                                    
          % parent-centric cropping if necessary.  good with low density at
          % edges of search region.
          bse=chrom(mod(ki-1,p)+1,:); %parent
          rr=rand(1,nvar);bseu=bnd(1,:).*rr+bse.*(1-rr);    % somewhere between parent and bound
          rr=rand(1,nvar);bsel=bnd(2,:).*rr+bse.*(1-rr);    % somewhere between parent and bound
          chx(ki,chx(ki,:)>bnd(1,:))=bseu(chx(ki,:)>bnd(1,:));       % crop to parentish for upper
          chx(ki,chx(ki,:)<bnd(2,:))=bsel(chx(ki,:)<bnd(2,:));       % crop to parentish for lower      
      end
  end
  
  
end % end of main loop


%% analyse results..
% 
% performs metric calculations based on weighted min-max and VADS for each
% target weight vector.
%
% For figure 1000 showing angular errors to weight vectors:
%
% 1. If both WMM and VADS have small angles to weight vector, then weight
%    vector should pass through Pareto surface.
% 2. If VADS close in angle to weight vector, but not WMM, then is on objective surface, but in
%    Pareto discontinuity
% 3. If WMM is close but VADS is not, then a sharp turn occured, or very
%    dense weight vectors - increase V and run again to get sharper VADS.
% 4. If Angle to WMM and VADS are both large, weight vector is likely to be
%    beoyond edge of objective region.


% other figures show surface profiles - useful to establish if
% convex/concave etc.
nth=1;  % [2 3 1] would sort in order based on col 2 first, then 3 as second priority etc.
wmtx=sortrows(wmtx,nth);  % sort based on nth objective objective.

if(gflaag)
    nrx2=cell(1,nmth);
    nrx3=cell(1,nmth);
    nrx4=cell(1,nmth);
    nrx5=cell(1,nmth);
    nrx6=cell(1,nmth);  % storage cells for metrics
    for z=1:nmth
        nrx3{z}=zeros(size(Bobj{z},1),nwt);
        nrx4{z}=zeros(size(Bobj{z},1),nwt);
        nrx5{z}=zeros(size(Bobj{z},1),nwt);
        nrx6{z}=zeros(size(Bobj{z},1),nwt);
        nrx7{z}=zeros(size(Bobj{z},1),nwt);
        for nx=1:size(Bobj{z},1)
            bt=Bobj{z}(nx,:)-tz_ref;       % make sure objective is offset!
            t2=(bt(ones(nwt,1),:).*wmtx)'; % search direction
            tt=t2;
            t2=sum(t2)./sqrt(sum((wmtx)'.^2))/sqrt(sum(bt.^2));  % dot products...
            t2(t2>1)=1;
            t2(t2<-1)=-1;
            nrx3{z}(nx,:)=sqrt(sum(tt.^2)); % combination - direction weighted euclidean norm (for profile)
            nrx4{z}(nx,:)=sum(abs(ones(nwt,1)*bt)'); % sum of objectives (for profile)
            nrx5{z}(nx,:)=acos(t2)*180/pi;  % error angle to weight vectors (in degrees)
            nrx6{z}(nx,:)=sum(abs(ones(nwt,1)*(bt./obj_scale))'); % sum of normalised objectives.
            nrx7{z}(nx,:)=sqrt(sum(abs(ones(nwt,1)*(bt./obj_scale))'.^2)); % sum of normalised objectives.
        end
    end
    %
    
    a=cell(1,nmth);
    b=cell(1,nmth);
    c=cell(1,nmth);
    cx=cell(1,nmth);
    cy=cell(1,nmth);
    d=cell(1,nmth);
    e=cell(1,nmth);
    
    for z=1:nmth
        [a{z},i]=min(nrx5{z});    % find closest to each target
        [p,q]=min(a{z});          % find closest of all
        i(q);                      % index of Bobj closest to a weight.
        ff=Bobj{z}(i(q),:)-tz_ref;
        ff_best=ff/sqrt(sum(ff.^2))     % target vector for best solution
        b{z}=diag(nrx3{z}(i,:))'; % capture corresponding metrics.
        c{z}=diag(nrx4{z}(i,:))';
        cx{z}=diag(nrx6{z}(i,:))';
        cy{z}=diag(nrx7{z}(i,:))';
    end
    
    cmtx=['b','r','k','g'];  % line colour sequence
    
    lc=cell(1,nmth);
    for z=1:nmth
        fnh=aggmthd{z};   % temp function handle to stop interpreter errors
        [tmp,tmp2,lc{z}]=fnh([],[]);  % call aggregation functions to get name
    end
    
    
    figure(1000)
    for z=1:nmth
        stairs(a{z},cmtx(z))
        hold on
    end
    hold off
    legend(lc,'location','best')
    xlabel('weight set')
    ylabel('angular error indication (degrees)')
    title('Best solution wrt weights - convergence indication and objective set limits')
    grid
    v=axis;
    axis([0.5 nwt+0.5 v(3) v(4)])
    
    
    figure(1001)
    for z=1:nmth
        stairs(c{z},cmtx(z))
        hold on
    end
    hold off
    legend(lc,'location','best')
    xlabel('weight set')
    ylabel('Objective Sum')
    title('Best solution wrt weights - weight set profile')
    v=axis;
    axis([0.5 nwt+0.5 v(3) v(4)])
    grid
    
    figure(1002)
    for z=1:nmth
        stairs(cx{z},cmtx(z))
        hold on
    end
    hold off
    legend(lc,'location','best')
    xlabel('weight set')
    ylabel('Normalised Objective Sum')
    title('Best solution wrt weights - weight set profile')
    v=axis;
    axis([0.5 nwt+0.5 v(3) v(4)])
    grid
    
    figure(1003)
    for z=1:nmth
        stairs(cy{z},cmtx(z))
        hold on
    end
    hold off
    legend(lc,'location','best')
    xlabel('weight set')
    ylabel('Normalised Objective Euclidean distance')
    title('Best solution wrt weights - weight set profile')
    v=axis;
    axis([0.5 nwt+0.5 v(3) v(4)])
    grid
    
    figure(1004)
    fk=size(Bobj{1},1);
    imagesc(sortrows((Bobj{1}-tz_ref(ones(fk,1),:))./obj_scale(ones(fk,1),:)))
    colorbar
    title('Sorted Normalised objectives')
end

bref=min(Bobj{1});
for z=2:nmth
    bref=min([bref;min(Bobj{z})]);
end
tz_ref_error=bref-tz_ref   % see if lower reference in error! (ie. none should be -ive)

toc
%  Bobj has all objectives
%  Bchrom has chromosomes
%  Bcons has constraint
%  pobj has pareto objectives
%  pchrom has pareto chromosomes
%  wmtx has target vectors.
%  tz_ref has minimum reference point
%  obj_scale has objective range after referencing.
