%
% Euclidean distance function. (decision space)
%
% Calling with [tc,R]=euc_dist(...chrom.) uses 'chrom' as 
% new target location and returns the target 
% location in 'tv' and the corresponding distance in 'R'
%
% calling with m=euc_dist(...chrom,tc) will generate the metric
% vector 'm' for the decision vectors 'chrom' against the corresponding
% target locations  in 'tc'.  Note chrom and tc must be the same size.
% if one target location is being used, it must be repeated so the matrices
% are of the same dimensions.
%
% E.J.Hughes March 2007

function [tv,R,name]=euc_dist(chrom,tc)    

if(nargout==3)     % if three outputs, we want name of function
    name='EUC';
    tv=[];
    R=[];
    return;
end
if(isempty(chrom))
    tv=[];
    R=[];
    return;
end
if(nargout==2)              % new vector calculation
    tv=chrom;     % target location in decision space
    R=zeros(size(tv,1),1);  % this location is optimal!
else                        % set update calculation
    dk=tc-chrom;                % vector to target
    tv=sqrt(sum(dk.^2,2));      % difference vector length
end
