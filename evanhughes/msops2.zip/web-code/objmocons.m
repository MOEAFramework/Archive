% objmocons.m  Tanaka Objective function, with extra constraints
%              on search region
% 
% constraint >=0 is ok.
%
% call with 4 outputs to get the number of objectives, constraints and
% upper/lower bound on decision variables.
% call with 2 outputs to get evaluation.
%
% E.J.Hughes 30/11/00


function [obj,c,ub,lb]=objmocons(Chrom,flaag)

nobj=2;                           % 2 objectives
ncons=4;                          % 3 constraints 

ub=pi*[1 1];  % upper bound on genes (2 gene problem)
lb=[0 0];  % lower bound on genes 

if nargout==4  %return problem size if requested
  obj=nobj;
  c=ncons;
  return;
end


[popsize,nvar]=size(Chrom);


% Loop for all chromosomes 

obj=zeros(popsize,nobj);
c  = ones(popsize,ncons);      % all unconstrained to start

for hjj=1:popsize

  chrom=Chrom(hjj,:);  % local copy

  x=chrom(1);
  y=chrom(2);
  
  %% Calculate objectives

  o1=x;
  o2=y;

  obj(hjj,:)=[o1 o2];
  
  c1 = (x^2) + (y^2) -1 - 0.1 * cos(16 * atan2(y,x));
  c2 = 0.5-( (x-0.5)^2 + (y-0.5)^2);
  
  c3= x-y;          % limit search region 
  c4= -(x-2*y);     % limit to tighter region
  
  c(hjj,:)  = [c1 c2 c3 c4];   % constraints
  
end





