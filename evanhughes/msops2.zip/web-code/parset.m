%
% parset.m   Identifies vectors on pareto set
%
% uses weighted min-max aggregation to identify them.
%
% E.J.Hughes 28/4/2006

function ind=parset(ob)
[p,nobj]=size(ob);
mm=min(ob,[],1)-eps;  % lower reference corner
ob=ob-mm(ones(p,1),:);
if(p)
    ind=logical(zeros(length(ob),1));     % initial index of good vectors
    
  if(~isempty(ob))
      % need to find Pareto set of the points
      dk=1./(ob+eps);         % invert for weighted min-max
      R=sqrt(sum(dk.^2,2));   % target vector lengths
      tv=dk./R(:,ones(1,nobj)); % unit vectors
      R=max(tv.*ob,[],2);       % get metric for each vector
      mval=1;                   % take first point as our reference
     
      %test to see if on Pareto surface...
      for nn=2:size(ob,1)
          %calculate weighted min-max metric
          t=ob(mval,:).*tv(nn*ones(length(mval),1),:); % find projection onto target vector
          m=max(t,[],2);     % weighted min-max
          if(min(m)>=R(nn))  % all beaten on new test vector, therefore lies on front
              % need to see if we need to remove any - they are beaten by new point on their own vector
              t=tv(mval,:).*ob(nn*ones(length(mval),1),:);  % distances along vectors
              m=max(t,[],2);     % weighted min-max
              idx=m<=R(mval);    % get any that are beaten
              mval(idx)=[];      % cut if beaten
              mval=[mval;nn];    % store results for point on objective front
          end
      end
  end

  ind(mval)=logical(1);     % get corrected index list
else
    ind=[];
end
