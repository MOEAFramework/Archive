%
% moersb.m  5d test results
%
% generate multi-objective equivalent random search metrics
%
% E.J.Hughes 28/3/2007
clear all
close all

if(~exist('5D_rand.mat'))
    randsrch_tot;         % generate random search data
end

load 5D_rand pobj obj nevt  % random search results 2D
        
load 080607a dat_x     % optimisation results 5D

nwt=200;   % number of weight vectors to sample

[ntm,ntt]=size(dat_x);    % total number of trials

odat=zeros(ntm,nwt);        % median moers results

[a,i]=sort(rand(1,size(pobj,1)));  % scramble random pareto set order
i=i(1:nwt);   % select random set of vectors to use

wmtx=1./(pobj(i,:)+eps);  % pull some pareto results to use as weight vectors
wmag=sqrt(sum(wmtx.^2,2));  % magnitude of vectors
wmtx=wmtx./wmag(:,ones(1,size(pobj,2)));  % normalised vectors
    
for n=1:ntm
    n
    for m=1:nwt
        ot=zeros(1,ntt);        % median moers results
        for z=1:ntt  % loop over all trials
            if(~isempty(dat_x{n,z}))
                sx=size(dat_x{n,z},1);    % no. of elements in set
                t=dat_x{n,z}.*wmtx(m*ones(sx,1),:);   % weighting
                ot(z)=min(max(t,[],2));      % get best result
            else
                ot(z)=inf;
            end
            odat(n,m)=median(ot);  % median performance on this metric vector
        end
    end
end


odx=odat;

nx=nevt;
%c=sum(cx<0,2)==0;  % valid solutions
%nx=size(obj,1);    % total number
%obj=obj(c,:);      % only good ones
%%
for n=1:ntm
    n
    for m=1:nwt
        t=obj.*wmtx(m*ones(size(obj,1),1),:);   % weighting
        odk(n,m)=sum(odx(n,m)>max(t,[],2));    % proportion still beating us  
    end
end

odp=odk/nx;
odp=log10(log(0.5))-log10(log1p(-odp));
%%
figure(1)
ls={'b-','r-','g-.','m-.','c--','k--'};
mn={'+','o','^','d','s','p','.','x','v'};
xx=sort(odp,2)-log10(5000);
ki=[2 4 5 6 7 9];
plot(1:200,xx(ki,:)')
h=zeros(1,length(ki));
for n=1:length(ki)
    hold on
    h(:,n)=plot(1:20:200,xx(ki(n),1:20:200),mn{ki(n)});
end
hold off
grid
legend(h(1,:),'full new','auto new','target orig','target new','random','full no arch','location','best','FontName','Arial')
xlabel('CDF Target vector index','FontName','Arial')
ylabel('Log Search Ratio','FontName','Arial')
title('MOERS analysis','FontName','Arial')
set(gca,'FontName','Arial')
drawnow
%print -depsc2 fig_moers.eps
%print -djpeg95 fig_moers.jpg



p=kruskalwallis(xx(1:2:5,:)')  % perform kruskallwallis analysis
p=kruskalwallis(xx(2:2:6,:)')  % perform kruskallwallis analysis

nx=zeros(ntm);
for n=1:ntm-1
    for m=n+1:ntm
        nx(n,m)=-kstest2(xx(n,:),xx(m,:),0.05,'larger')+kstest2(xx(n,:),xx(m,:),0.05,'smaller');
    end
end

nx