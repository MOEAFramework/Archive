%
% Large Random Search
%
% First line of objective, constraint and chromosome are from best solution found
%
% E.J.Hughes 12/4/2006
tic
disp('Generating random search data, this may take a while')
hdfg = waitbar(0,'Please wait, generating Random search data...');

for rnx=1:2
    
    if(rnx==1)
        fn=@objmocons;        % extra-constrained tanaka function
        nevt=1e8;   % total number of points to use in search
    else
        fn=@objhigh2;        % simple 5 objective function
        nevt=1e6;   % total number of points to use in search
    end
    

    gflaag=1;   %plot figures at end
%% Main code
	       
%% initialise population and variables

% call objective function to 
% get number of objectives and constraints and genes
[nobj,ncons,ub,lb]=fn([]);
bnd=[ub;lb];                % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene
nvar=size(bnd,2);           % number of variables
  
objq=cell(2,100);     % do 100 smaller tries
ncon=zeros(1,100);    % number constrained and chopped

nev=nevt/100;
for ff=1:100
    ff
    waitbar((ff+(rnx-1)*200)/400,hdfg);  % show waiting bar
    chrom=rand(nev,nvar).*(ones(nev,1)*rng)+ones(nev,1)*bnd(2,:);
                                        % initial pop. lb<= x <=ub
    [obj,cx]=fn(chrom);            % evaluate initial pop.
    if(ncons==0) cx=ones(nev,1); end        % fix if no constraint
    c=sum(cx<0,2)==0;              % evaluate constraints (consx>0 is good)

    % get pareto set
    mm=find(c==1);
    r=parset(obj(c,:));
    mm=mm(r==1);
    pobj=obj(mm,:);
%    pchrom=chrom(mm,:);

   objq{1,ff}=obj(c,:);
   objq{2,ff}=pobj;
   ncon=sum(~mm);     % number clipped out
end

tobj=0;
tpobj=0;
for ff=1:100
    tobj=tobj+size(objq{1,ff},1);
    tpobj=tpobj+size(objq{2,ff},1);
end

%%
pobj=zeros(tpobj,size(obj,2));
obj=zeros(tobj,size(obj,2));

% re-construct full matrix:
pr=1;
or=1;
for ff=1:100
    obj(or:or+size(objq{1,ff},1)-1,:)=objq{1,ff};
    or=or+size(objq{1,ff},1);
    pobj(pr:pr+size(objq{2,ff},1)-1,:)=objq{2,ff};
    pr=pr+size(objq{2,ff},1);
end
%%
waitbar((150+(rnx-1)*200)/400,hdfg);  % show waiting bar

r=parset(pobj);
pobj=pobj(r==1,:);  % create pareto set.

totncon=sum(ncon);  % number cut out due to constraint

if(rnx==1)
    save 2D_rand obj pobj totncon nevt  % used for 2D data
else
    save 5D_rand obj pobj totncon nevt   % used for 5D data
end


if(gflaag)
    figure(1)
    if(nobj==2)
        plot(pobj(:,1),pobj(:,2),'.')
        grid
        axis([lb(1) ub(1) lb(2) ub(2)])
    else
        plot(pobj')
        grid
    end
    title('Chromosomes')
    xlabel('Gene number')
    ylabel('Gene value')
    
    drawnow
end

end
close(hdfg);
toc