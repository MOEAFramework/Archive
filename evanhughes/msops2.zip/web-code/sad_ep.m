
function  [chx,sgx]=sad_ep(obj,chrom,cons,sg,fobj,fchrom,bnd,sigma,nvar,p,xovr,mutr,tau,Nct)

  chx=zeros(p,nvar);   % create storage space for new chrom
  sgx=zeros(p,1);

for ki=1:p
          r=ki;
          % do large tournament to find other parents via crowding from archive
          % randomly crowd in objective or decision space
          [tmp,ix]=sort(rand(1,size(fobj,1)));   % generate scrambled index list of archive+pop
          Nca=min(Nct,floor(length(ix)/2));
          ix=ix(1:Nca*2);
          
          dst_o=sum((obj(r*ones(size(ix,2),1),:)-fobj(ix,:)).^2,2);   % euclidean in objective
          dst_c=sum((chrom(r*ones(size(ix,2),1),:)-fchrom(ix,:)).^2,2);     % euclidean in chrom
          if(rand>0.5)                                % mask for obj/chrom
              dst=dst_o;
          else
              dst=dst_c;
          end
          dst=reshape(dst,Nca,2);  % get the index's for the trials
          ix=reshape(ix,Nca,2);  % get the index's for the trials
          
          [tmp,r2]=min(dst,[],1);     % Nct tournament of distance
          r2=diag(ix(r2,:))';          % recast to index
          
          alpha=rand(1,nvar)*1.5-0.25; % create vector of random
          % then crossover - not good for rotated problems!
          alti=alpha.*chrom(mod(ki-1,p)+1,:)+(1-alpha).*fchrom(r2(1),:);
              
          chx(ki,:)=chrom(mod(ki-1,p)+1,:);   % just copy if not crossing
          mx=rand(1,nvar)<xovr;
          chx(ki,mx)=alti(mx);      % crossover genes at rate.
   
          sgx(ki)=sg(ki)*exp(randn*tau);            % mutate mutation size

          sgx(ki)=min(1,sgx(ki));  % crop mutation spreads
  
          % adds Gaussian noise for
          % a mutation with standard
          % deviation of `sigma',
          % if selected based on mutr
          chx(ki,:)=chx(ki,:)+(rand(1,nvar)<mutr).*randn(1,nvar).*(sgx(ki)*sigma);
                                    
          % parent-centric cropping if necessary.  good with low density at
          % edges of search region.
          % DO NOT use simple edge cropping as it is very poor!! 
          
          bse=chrom(mod(ki-1,p)+1,:); %parent
          rr=rand(1,nvar);bseu=bnd(1,:).*rr+bse.*(1-rr);    % somewhere between parent and bound
          rr=rand(1,nvar);bsel=bnd(2,:).*rr+bse.*(1-rr);    % somewhere between parent and bound
          chx(ki,chx(ki,:)>bnd(1,:))=bseu(chx(ki,:)>bnd(1,:));       % crop to parentish for upper
          chx(ki,chx(ki,:)<bnd(2,:))=bsel(chx(ki,:)<bnd(2,:));       % crop to parentish for lower      
      end