%
% Random Search
%
% use [obj,cons,chrom] = randsrch('myobjective',popsize,maxgen,<gflaag>,<params>)
%
% Product of popsize and maxgen are used for points to check.  Top popsize
% are returned.  gflaag is optional and gflaag=1 will plot out graph of
% final chroms.
% <params> element is ignored
%
% First line of objective, constraint and chromosome are from best solution found
%
% E.J.Hughes 12/4/2006

%function pobj=msops(fn,p,maxgen,gflaag)
%fn=@objmocons;
fn=@objhigh2;        % simple 5 objective function
% params is not used.
nev=50*100;

gflaag=1;
%% Main code
	       
%% initialise population and variables
%nev=p+lambda*(maxgen-1);    % calculate number of evaluations

% call objective function to 
% get number of objectives and constraints and genes
[nobj,ncons,ub,lb]=fn([]);  
bnd=[ub;lb];                % bound array
rng=bnd(1,:)-bnd(2,:);      % range of each gene
nvar=size(bnd,2);           % number of variables
  
chrom=rand(nev,nvar).*(ones(nev,1)*rng)+ones(nev,1)*bnd(2,:);
                                        % initial pop. lb<= x <=ub
[obj,cx]=fn(chrom);            % evaluate initial pop.
if(ncons==0) cx=ones(nev,1); end        % fix if no constraint
c=sum(cx<0,2)==0;              % evaluate constraints (consx>0 is good)

% get pareto set
mm=find(c==1);
r=parset(obj(mm,:));
mm=mm(r==1);
pobj=obj(mm,:);
pchrom=chrom(mm,:);

if(gflaag)
    figure(1)
    if(nobj==2)
        plot(pobj(:,1),pobj(:,2),'.')
        grid
        axis([lb(1) ub(1) lb(2) ub(2)])
    else
        plot(pobj')
        grid
    end
    title('Chromosomes')
    xlabel('Gene number')
    ylabel('Gene value')
    
    drawnow
end
