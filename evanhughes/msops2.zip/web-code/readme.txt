The main optimisaiton code is run using 'msops2'. 
The fist few lines of the file need to be editted to change the
optimisers behaviour, a few sample configurations are given.

To reproduce the 2D objective results, run 'moers'

To reproduce the 5D objective results, run 'moersb'

Before the figures are plotted, the random search reference
data are generated (zip file would be >30MB if data were included)
This process is automatic and will save off the results ready
for both the 2D and 5D analysis.  The process takes about
10 minutes on my laptop.

A PDF of the paper is also included in the zip.
