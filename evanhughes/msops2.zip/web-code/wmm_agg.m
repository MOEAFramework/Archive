%
% weighted min-max aggregation function.
%
% Calling with [tv,R]=wmm_agg(obj) uses 'obj' as 
% new target vector directions and returns the target 
% vectors in 'tv' and the corresponding metrics in 'R'
%
% calling with m=wmm_agg(obj,tv) will generate the metric
% vector 'm' for the objectives 'obj' against the corresponding
% target vectors  in 'tv'.  Note, obj and tv must be the same size.
% if one target vector is being used, it must be repeated so the matrices
% are of the same dimensions.
%
% E.J.Hughes September 2006

function [tv,R,name]=wmm_agg(obj,tv)    

nobj=size(obj,2);
if(nargout==3)     % if three outputs, we want name of function
    name='WMM';
    tv=[];
    R=[];
    return;
end
if(nargout==2)              % new vector calculation
%    dk=1./(obj+eps);            % invert for weighted min-max vector
    dk=obj;                     % will need to invert for weighted min-max vector
    lv=sqrt(sum(dk.^2,2));      % target vector length
    tv=dk./lv(:,ones(1,nobj));  % unit length target vector
    dk=1./(tv+eps);            % invert for weighted min-max vector
    lv=sqrt(sum(dk.^2,2));      % target vector length
    tvx=dk./lv(:,ones(1,nobj));  % unit length target vector
    R=max(tvx.*obj,[],2);        % get metric for each vector on self.
else                        % set update calculation
    dk=1./(tv+eps);            % invert for weighted min-max vector
    lv=sqrt(sum(dk.^2,2));      % target vector length
    tv=dk./lv(:,ones(1,nobj));  % unit length target vector
    t=obj.*tv;                  % find projection of set onto target vector
    tv=max(t,[],2);             % weighted min-max
end
