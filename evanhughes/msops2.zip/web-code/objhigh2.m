%
% objhigh.m
%
% Objective function that is for high-dimensional test.
% E.J.Hughes 6/3/2007

function [obj,c,ub,lb]=objhigh2(chrom,nobj)

if(nargin==1)
    nobj=5;    % set default to a 5D
end

% These lines define the upper/lower bounds on decision space.
% This function allows range (0,1] to be used by optimiser for simplicity
ub=ones(1,nobj);% upper bound on genes
lb=zeros(1,nobj);% lower bound on genes

ncons=2;                % no. of constraints, put a dummy constraint in. 

% if function is called as [o,c,ub,lb]=objpri()
% returns:
% o = number of objectives
% c = number of constraints
% ub = vector of upper decision variable bounds
% lb = vector of lower decision variable bounds
if nargout==4
  obj=nobj;
  c=ncons;
  return;
end

[popsize,nvar]=size(chrom);  % chrom is array of chromosomes

obj=zeros(popsize,nobj);      % allocate output space for objectives
c=ones(popsize,ncons);        % allocate output space for constraints
for n=1:popsize               % loop for all
    [obj(n,:),c(n,:)]=objfcn(chrom(n,:));  % calculate objective
end

    
% acutal objective function
function [o,c]=objfcn(chr)

o=chr;
ll=sqrt(sum(chr.^2));  % length of objective vector
c1=ll - 1; % constraint ok if >=0, invalid otherwise.
c2=sum(chr)/ll/sqrt(nobj) - cosd(15);     % central cone only.  
c=[c1 c2];
end

end